package org.razvan.jzx;

import java.applet.Applet;
import java.applet.AppletContext;

public class AppletLogger
  implements ILogger
{
  private AppletContext m_appletContext;

  public AppletLogger(Applet paramApplet)
  {
    this.m_appletContext = paramApplet.getAppletContext();
  }

  public void log(int paramInt, String paramString)
  {
    this.m_appletContext.showStatus("Channel: " + paramInt + ", " + paramString);
  }

  public void log(int paramInt, Throwable paramThrowable)
  {
    this.m_appletContext.showStatus("Channel: " + paramInt + ", " + paramThrowable.getMessage());
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.AppletLogger
 * JD-Core Version:    0.6.2
 */