package org.razvan.jzx;

public abstract class BaseComponent
{
  protected BaseSpectrum m_spectrum;
  protected ILogger m_logger;

  public BaseSpectrum getSpectrum()
  {
    return this.m_spectrum;
  }

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    this.m_spectrum = paramBaseSpectrum;
    this.m_logger = paramILogger;
  }

  public void terminate()
  {
    this.m_spectrum = null;
    this.m_logger = null;
  }

  public abstract void reset();

  public abstract void load(BaseLoader paramBaseLoader);
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseComponent
 * JD-Core Version:    0.6.2
 */