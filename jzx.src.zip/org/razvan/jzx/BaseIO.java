package org.razvan.jzx;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

public class BaseIO extends BaseComponent
{
  public static final float SAMPLE_FREQ = 48000.0F;
  public static final int LINE_BUF_SIZE = 4096;
  private static final double MICROSECONDS_PER_TSTATE = 0.2855217298596683D;
  private static final double MICROSECONDS_PER_SAMPLE = 20.833333333333332D;
  private SourceDataLine m_line;
  protected byte[] m_buffer = new byte[4096];
  protected int m_index;
  public static final int P_ULA = 254;
  public static final int B_ULA = 1;
  public static final int B_BORDER = 7;
  public static final int B_MIC = 8;
  public static final int B_SPEAKER = 16;
  public static final int B_KEYBOARD = 31;
  public static final int B_EAR = 32;
  public static final int P_KEMPSTON = 31;
  public static final int B_KEMPSTON = 32;
  public static final int B_RIGHT = 1;
  public static final int B_LEFT = 2;
  public static final int B_DOWN = 4;
  public static final int B_UP = 8;
  public static final int B_FIRE = 16;
  public static final int P_SINCLAIR1 = 61438;
  public static final int P_SINCLAIR2 = 63486;
  protected int m_lastBorderColor = 7;
  protected int[] m_inPorts;
  protected int[] m_outPorts;
  protected int[] m_keyPorts;
  protected Z80 m_cpu;
  protected BaseMemory m_memory;
  protected BaseScreen m_screen;
  protected int m_speakerLevel;

  public static int getAudioSamplesForTStates(int paramInt)
  {
    int i = (int)(paramInt * 0.2855217298596683D / 20.833333333333332D);
    if (i == 0)
      return 1;
    return i;
  }

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_keyPorts = new int[9];
    this.m_inPorts = new int[256];
    this.m_outPorts = new int[256];
    this.m_cpu = this.m_spectrum.getCPU();
    this.m_memory = this.m_spectrum.getMemory();
    this.m_screen = this.m_spectrum.getScreen();
    AudioFormat localAudioFormat = new AudioFormat(AudioFormat.Encoding.PCM_UNSIGNED, 48000.0F, 8, 1, 1, 48000.0F, true);
    DataLine.Info localInfo = new DataLine.Info(SourceDataLine.class, localAudioFormat, 8192);
    if (!AudioSystem.isLineSupported(localInfo))
      this.m_logger.log(1, "Unsupported audio format: " + localAudioFormat);
    try
    {
      this.m_line = ((SourceDataLine)AudioSystem.getLine(localInfo));
      this.m_line.open();
      this.m_line.start();
    }
    catch (LineUnavailableException localLineUnavailableException)
    {
      this.m_logger.log(0, localLineUnavailableException);
      this.m_line = null;
    }
  }

  public void reset()
  {
    for (int i = 0; i < this.m_keyPorts.length; i++)
      this.m_keyPorts[i] = 255;
    for (i = 0; i < this.m_inPorts.length; i++)
      this.m_inPorts[i] = 0;
    for (i = 0; i < this.m_outPorts.length; i++)
      this.m_outPorts[i] = 0;
    if (this.m_line != null)
      this.m_line.drain();
  }

  public void terminate()
  {
    if (this.m_line != null)
    {
      this.m_line.stop();
      this.m_line.close();
      this.m_line = null;
    }
    this.m_keyPorts = null;
    this.m_inPorts = null;
    this.m_outPorts = null;
    this.m_cpu = null;
    this.m_memory = null;
    this.m_screen = null;
    super.terminate();
  }

  public int in8(int paramInt)
  {
    if ((paramInt & 0x20) == 0)
      return this.m_inPorts[31] & 0x1F;
    if ((paramInt & 0x1) == 0)
    {
      i = this.m_spectrum.getIssue() == 2 ? 255 : 223;
      if ((paramInt & 0x8000) == 0)
        i &= this.m_keyPorts[7];
      if ((paramInt & 0x4000) == 0)
        i &= this.m_keyPorts[6];
      if ((paramInt & 0x2000) == 0)
        i &= this.m_keyPorts[5];
      if ((paramInt & 0x1000) == 0)
        i &= this.m_keyPorts[4];
      if ((paramInt & 0x800) == 0)
        i &= this.m_keyPorts[3];
      if ((paramInt & 0x400) == 0)
        i &= this.m_keyPorts[2];
      if ((paramInt & 0x200) == 0)
        i &= this.m_keyPorts[1];
      if ((paramInt & 0x100) == 0)
        i &= this.m_keyPorts[0];
      this.m_cpu.addTStates(1);
      return i;
    }
    int i = this.m_spectrum.getVline();
    return i < 192 ? this.m_memory.read8(0x5800 | (i & 0xF8) << 2) : 255;
  }

  public void out(int paramInt1, int paramInt2)
  {
    if ((paramInt1 & 0x1) == 0)
    {
      if (this.m_lastBorderColor != (paramInt2 & 0x7))
      {
        this.m_lastBorderColor = (paramInt2 & 0x7);
        this.m_screen.setBorderColor(this.m_lastBorderColor);
      }
      if ((paramInt2 & 0x10) != 0)
        this.m_speakerLevel = -17;
      else
        this.m_speakerLevel = 0;
      if ((this.m_spectrum.getVline() < 192) && (this.m_cpu.getTStates() < 128))
        this.m_cpu.addTStates(4);
    }
    this.m_outPorts[(paramInt1 & 0xFF)] = paramInt2;
  }

  public void advance(int paramInt)
  {
    this.m_index = mixSound(paramInt, this.m_speakerLevel);
    if (this.m_index >= this.m_buffer.length)
    {
      this.m_line.write(this.m_buffer, 0, 4096);
      for (int i = 0; i < this.m_buffer.length; i++)
        this.m_buffer[i] = 0;
      this.m_index = 0;
    }
  }

  protected int mixSound(int paramInt1, int paramInt2)
  {
    int i = this.m_index;
    int j = getAudioSamplesForTStates(paramInt1);
    while ((i < this.m_index + j) && (i < this.m_buffer.length))
    {
      int k = (this.m_buffer[i] & 0xFF) + (paramInt2 & 0xFF);
      if (k > 255)
        k = 255;
      this.m_buffer[(i++)] = ((byte)k);
    }
    return i;
  }

  public void orIn(int paramInt1, int paramInt2)
  {
    this.m_inPorts[paramInt1] |= paramInt2;
  }

  public void andIn(int paramInt1, int paramInt2)
  {
    this.m_inPorts[paramInt1] &= paramInt2;
  }

  public void orOut(int paramInt1, int paramInt2)
  {
    this.m_outPorts[paramInt1] |= paramInt2;
  }

  public void andOut(int paramInt1, int paramInt2)
  {
    this.m_outPorts[paramInt1] &= paramInt2;
  }

  public void orKey(int paramInt1, int paramInt2)
  {
    this.m_keyPorts[paramInt1] |= paramInt2;
  }

  public void andKey(int paramInt1, int paramInt2)
  {
    this.m_keyPorts[paramInt1] &= paramInt2;
  }

  public void load(BaseLoader paramBaseLoader)
  {
    out(254, paramBaseLoader.getBorder());
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseIO
 * JD-Core Version:    0.6.2
 */