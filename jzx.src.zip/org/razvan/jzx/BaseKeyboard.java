package org.razvan.jzx;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class BaseKeyboard extends BaseComponent
  implements KeyListener
{
  protected static final int JOY_UP = 104;
  protected static final int JOY_DOWN = 98;
  protected static final int JOY_LEFT = 100;
  protected static final int JOY_RIGHT = 102;
  protected static final int JOY_FIRE = 96;
  protected static final int[][] m_keyTable = { { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 7, 254 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 4, 254 }, { 3, 254 }, { 3, 253 }, { 3, 251 }, { 3, 247 }, { 3, 239 }, { 4, 239 }, { 4, 247 }, { 4, 251 }, { 4, 253 }, { 8, 0 }, { 5, 253 }, { 8, 0 }, { 6, 253 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 1, 254 }, { 7, 239 }, { 0, 247 }, { 1, 251 }, { 2, 251 }, { 1, 247 }, { 1, 239 }, { 6, 239 }, { 5, 251 }, { 6, 247 }, { 6, 251 }, { 6, 253 }, { 7, 251 }, { 7, 247 }, { 5, 253 }, { 5, 254 }, { 2, 254 }, { 2, 247 }, { 1, 253 }, { 2, 239 }, { 5, 247 }, { 0, 239 }, { 2, 253 }, { 0, 251 }, { 5, 239 }, { 0, 253 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 }, { 8, 0 } };
  protected boolean m_unshiftCursor;
  protected BaseIO m_io;
  protected BaseScreen m_screen;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_io = this.m_spectrum.getIO();
    this.m_screen = this.m_spectrum.getScreen();
  }

  public void reset()
  {
  }

  public void terminate()
  {
    this.m_io = null;
    super.terminate();
  }

  public void keyTyped(KeyEvent paramKeyEvent)
  {
  }

  public void keyPressed(KeyEvent paramKeyEvent)
  {
    int i = paramKeyEvent.getKeyCode();
    if (i == 104)
      this.m_io.orIn(31, 8);
    else if (i == 98)
      this.m_io.orIn(31, 4);
    else if (i == 100)
      this.m_io.orIn(31, 2);
    else if (i == 102)
      this.m_io.orIn(31, 1);
    else if (i == 96)
      this.m_io.orIn(31, 16);
    switch (i)
    {
    case 10:
      this.m_io.andKey(6, 254);
      break;
    case 8:
    case 127:
      this.m_io.andKey(0, 254);
      this.m_io.andKey(4, 254);
      break;
    case 27:
      this.m_io.andKey(0, 254);
      this.m_io.andKey(3, 254);
      break;
    case 38:
      if (!this.m_unshiftCursor)
        this.m_io.andKey(0, 254);
      this.m_io.andKey(4, 247);
      break;
    case 40:
      if (!this.m_unshiftCursor)
        this.m_io.andKey(0, 254);
      this.m_io.andKey(4, 239);
      break;
    case 37:
      if (!this.m_unshiftCursor)
        this.m_io.andKey(0, 254);
      this.m_io.andKey(3, 239);
      break;
    case 39:
      if (!this.m_unshiftCursor)
        this.m_io.andKey(0, 254);
      this.m_io.andKey(4, 251);
      break;
    case 44:
      this.m_io.andKey(7, 253);
      this.m_io.andKey(7, 247);
      break;
    case 45:
      this.m_io.andKey(7, 253);
      this.m_io.andKey(6, 247);
      break;
    case 46:
      this.m_io.andKey(7, 253);
      this.m_io.andKey(7, 251);
      break;
    case 47:
      this.m_io.andKey(7, 253);
      this.m_io.andKey(0, 239);
      break;
    case 59:
      break;
    case 61:
      break;
    case 16:
      this.m_io.andKey(0, 254);
      break;
    case 17:
      this.m_io.andKey(7, 253);
      break;
    default:
      if (i < 128)
        this.m_io.andKey(m_keyTable[i][0], m_keyTable[i][1]);
      break;
    }
  }

  public void keyReleased(KeyEvent paramKeyEvent)
  {
    int i = paramKeyEvent.getKeyCode();
    if (i == 104)
      this.m_io.andIn(31, -9);
    else if (i == 98)
      this.m_io.andIn(31, -5);
    else if (i == 100)
      this.m_io.andIn(31, -3);
    else if (i == 102)
      this.m_io.andIn(31, -2);
    else if (i == 96)
      this.m_io.andIn(31, -17);
    switch (i)
    {
    case 9:
      this.m_unshiftCursor = (!this.m_unshiftCursor);
      break;
    case 10:
      this.m_io.orKey(6, 1);
      break;
    case 8:
    case 127:
      this.m_io.orKey(0, 1);
      this.m_io.orKey(4, 1);
      break;
    case 27:
      this.m_io.orKey(0, 1);
      this.m_io.orKey(3, 1);
      break;
    case 38:
      if (!this.m_unshiftCursor)
        this.m_io.orKey(0, 1);
      this.m_io.orKey(4, 8);
      break;
    case 40:
      if (!this.m_unshiftCursor)
        this.m_io.orKey(0, 1);
      this.m_io.orKey(4, 16);
      break;
    case 37:
      if (!this.m_unshiftCursor)
        this.m_io.orKey(0, 1);
      this.m_io.orKey(3, 16);
      break;
    case 39:
      if (!this.m_unshiftCursor)
        this.m_io.orKey(0, 1);
      this.m_io.orKey(4, 4);
      break;
    case 44:
      this.m_io.orKey(7, -248);
      this.m_io.orKey(7, 2);
      break;
    case 45:
      this.m_io.orKey(6, -248);
      this.m_io.orKey(7, 2);
      break;
    case 46:
      this.m_io.orKey(7, -252);
      this.m_io.orKey(7, 2);
      break;
    case 47:
      this.m_io.orKey(0, -240);
      this.m_io.orKey(7, 2);
      break;
    case 59:
      break;
    case 61:
      break;
    case 16:
      this.m_io.orKey(0, 1);
      break;
    case 17:
      this.m_io.orKey(7, 2);
      break;
    default:
      if (i < 128)
        this.m_io.orKey(m_keyTable[i][0], m_keyTable[i][1] ^ 0xFFFFFFFF);
      break;
    }
  }

  public void load(BaseLoader paramBaseLoader)
  {
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseKeyboard
 * JD-Core Version:    0.6.2
 */