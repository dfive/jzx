package org.razvan.jzx;

import java.io.IOException;
import java.net.URL;

public abstract class BaseLoader
{
  public static final int MODE_48 = 0;
  public static final int MODE_128 = 1;
  protected int m_af16;
  protected int m_bc16;
  protected int m_de16;
  protected int m_hl16;
  protected int m_af16alt;
  protected int m_bc16alt;
  protected int m_de16alt;
  protected int m_hl16alt;
  protected int m_ix16;
  protected int m_iy16;
  protected int m_sp16;
  protected int m_pc16;
  protected int m_r8;
  protected int m_i8;
  protected int m_im2;
  protected int m_iff1a;
  protected int m_iff1b;
  protected int m_mode;
  protected int m_issue;
  protected int m_border;
  protected int m_last0x7ffd;
  protected int m_last0xfffd;
  protected SnapshotMemory m_memory;
  protected URL m_url;
  protected ILogger m_logger;

  public int getAF16()
  {
    return this.m_af16;
  }

  public int getBC16()
  {
    return this.m_bc16;
  }

  public int getDE16()
  {
    return this.m_de16;
  }

  public int getHL16()
  {
    return this.m_hl16;
  }

  public int getAF16ALT()
  {
    return this.m_af16alt;
  }

  public int getBC16ALT()
  {
    return this.m_bc16alt;
  }

  public int getDE16ALT()
  {
    return this.m_de16alt;
  }

  public int getHL16ALT()
  {
    return this.m_hl16alt;
  }

  public int getIX16()
  {
    return this.m_ix16;
  }

  public int getIY16()
  {
    return this.m_iy16;
  }

  public int getSP16()
  {
    return this.m_sp16;
  }

  public int getPC16()
  {
    return this.m_pc16;
  }

  public int getR8()
  {
    return this.m_r8;
  }

  public int getI8()
  {
    return this.m_i8;
  }

  public int getIM2()
  {
    return this.m_im2;
  }

  public int getIFF1a()
  {
    return this.m_iff1a;
  }

  public int getIFF1b()
  {
    return this.m_iff1b;
  }

  public int getMode()
  {
    return this.m_mode;
  }

  public int getIssue()
  {
    return this.m_issue;
  }

  public int getBorder()
  {
    return this.m_border;
  }

  public int getLast0x7ffd()
  {
    return this.m_last0x7ffd;
  }

  public int getLast0xfffd()
  {
    return this.m_last0xfffd;
  }

  public BaseMemory getMemory()
  {
    return this.m_memory;
  }

  public BaseLoader(ILogger paramILogger, URL paramURL)
  {
    this.m_logger = paramILogger;
    this.m_url = paramURL;
    this.m_memory = new SnapshotMemory();
    this.m_memory.init(null, paramILogger);
  }

  public abstract void load(String paramString)
    throws IOException;
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseLoader
 * JD-Core Version:    0.6.2
 */