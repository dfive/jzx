package org.razvan.jzx;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public abstract class BaseMemory extends BaseComponent
{
  public static final int PAGE_SIZE = 16384;
  public static final int ROM0 = 0;
  public static final int ROM1 = 1;
  public static final int ROM2 = 2;
  public static final int ROM3 = 3;
  public static final int RAM0 = 4;
  public static final int RAM1 = 5;
  public static final int RAM2 = 6;
  public static final int RAM3 = 7;
  public static final int RAM4 = 8;
  public static final int RAM5 = 9;
  public static final int RAM6 = 10;
  public static final int RAM7 = 11;
  protected int[] m_frameToPage;
  protected byte[][] m_frame;
  protected byte[][] m_page;
  protected BaseScreen m_screen;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_frameToPage = new int[4];
    this.m_page = new byte[12][16384];
    this.m_frame = new byte[4][];
    if (this.m_spectrum != null)
      this.m_screen = this.m_spectrum.getScreen();
    pageIn(0, 0);
    pageIn(1, 9);
    pageIn(2, 6);
    pageIn(3, 4);
  }

  public void terminate()
  {
    this.m_frameToPage = null;
    this.m_page = ((byte[][])null);
    this.m_frame = ((byte[][])null);
    this.m_screen = null;
    super.terminate();
  }

  protected void readROM(String paramString, byte[] paramArrayOfByte)
    throws IOException
  {
    URL localURL = getClass().getResource(paramString);
    if (localURL == null)
      throw new IOException("Could not find resource '" + paramString + "'");
    URLConnection localURLConnection = localURL.openConnection();
    InputStream localInputStream = localURLConnection.getInputStream();
    try
    {
      int i = 0;
      while (true)
      {
        int j = localInputStream.read(paramArrayOfByte, i, paramArrayOfByte.length - i);
        if (j <= 0)
          break;
        i += j;
      }
    }
    finally
    {
      localInputStream.close();
    }
  }

  public void pageIn(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) && (paramInt2 >= 4))
    {
      this.m_logger.log(1, "Ignored attempt to page RAM at 0x0000");
      return;
    }
    this.m_frameToPage[paramInt1] = paramInt2;
    this.m_frame[paramInt1] = this.m_page[paramInt2];
  }

  public byte[] getBytes(int paramInt)
  {
    return this.m_page[paramInt];
  }

  public int read8(int paramInt)
  {
    return this.m_frame[(paramInt >> 14)][(paramInt & 0x3FFF)] & 0xFF;
  }

  public void write8(int paramInt1, int paramInt2)
  {
    int i = paramInt1 >> 14;
    int j = paramInt1 & 0x3FFF;
    if (this.m_frame[i][j] == (byte)paramInt2)
      return;
    int k = this.m_frameToPage[i];
    if (k < 4)
      return;
    this.m_frame[i][j] = ((byte)paramInt2);
    if ((this.m_spectrum != null) && (k == this.m_screen.getPage()))
      if (j < 6144)
        this.m_screen.screenTouch(paramInt1);
      else if (j < 6912)
        this.m_screen.attrTouch(paramInt1);
  }

  public int read16(int paramInt)
  {
    return read8(paramInt + 1 & 0xFFFF) << 8 | read8(paramInt);
  }

  public void write16(int paramInt1, int paramInt2)
  {
    write8(paramInt1, paramInt2 & 0xFF);
    write8(paramInt1 + 1 & 0xFFFF, paramInt2 >> 8);
  }

  public void load(BaseLoader paramBaseLoader)
  {
    BaseMemory localBaseMemory = paramBaseLoader.getMemory();
    for (int i = 4; i <= 11; i++)
    {
      byte[] arrayOfByte1 = localBaseMemory.getBytes(i);
      byte[] arrayOfByte2 = getBytes(i);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, 16384);
    }
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i <= 11; i++)
    {
      localStringBuffer.append("P" + i + "=");
      int j = 0;
      for (int k = 0; k < 16384; k++)
        j += (this.m_page[i][k] & 0xFF);
      localStringBuffer.append(j);
      localStringBuffer.append(" ");
    }
    return localStringBuffer.toString();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseMemory
 * JD-Core Version:    0.6.2
 */