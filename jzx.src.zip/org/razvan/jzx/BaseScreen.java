package org.razvan.jzx;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

public abstract class BaseScreen extends Canvas
{
  public static final int PIXEL_START = 16384;
  public static final int ROWS = 24;
  public static final int COLS = 32;
  public static final int X_PIXELS = 256;
  public static final int Y_PIXELS = 192;
  public static final int PIXEL_LENGTH = 6144;
  public static final int ATTR_START = 22528;
  public static final int ATTR_LENGTH = 768;
  public static final int BORDER_PIXELS = 30;
  public static final int BLACK = 0;
  public static final int BLUE = 1;
  public static final int RED = 2;
  public static final int MAGENTA = 3;
  public static final int GREEN = 4;
  public static final int CYAN = 5;
  public static final int YELLOW = 6;
  public static final int WHITE = 7;
  public static final int BRIGHT_BLACK = 8;
  public static final int BRIGHT_BLUE = 9;
  public static final int BRIGHT_RED = 10;
  public static final int BRIGHT_MAGENTA = 11;
  public static final int BRIGHT_GREEN = 12;
  public static final int BRIGHT_CYAN = 13;
  public static final int BRIGHT_YELLOW = 14;
  public static final int BRIGHT_WHITE = 15;
  public static final int FLASH = 128;
  public static final int BRIGHT = 64;
  public static final int PAPER = 56;
  public static final int INK = 7;
  private int CHARSET_ADDR = 15616;
  protected int m_scale = 1;
  protected int m_screenWidth = 256 * this.m_scale;
  protected int m_screenHeight = 192 * this.m_scale;
  private int m_fullWidth = this.m_screenWidth + 60 * this.m_scale;
  private int m_fullHeight = this.m_screenHeight + 60 * this.m_scale;
  protected static final Color[] s_colorPalette = { new Color(0), new Color(191), new Color(12517376), new Color(12517567), new Color(48896), new Color(49087), new Color(12566272), new Color(12566463), new Color(0), new Color(255), new Color(16711680), new Color(16711935), new Color(65280), new Color(65535), new Color(16776960), new Color(16777215) };
  protected static final int[] s_rgbPalette = { 0, 191, 12517376, 12517567, 48896, 49087, 12566272, 12566463, 0, 255, 16711680, 16711935, 65280, 65535, 16776960, 16777215 };
  protected boolean m_flashPhase;
  protected int m_borderColor;
  protected int[] m_inkTable;
  protected int[] m_paperTable;
  protected boolean[] m_screenChanged;
  protected boolean m_screenDirty;
  protected boolean m_borderDirty;
  protected Image m_offscreenBorder;
  protected Graphics m_offscreenBorderGraphics;
  protected Image m_offscreenImage;
  protected Graphics m_offscreenImageGraphics;
  protected BaseSpectrum m_spectrum;
  protected ILogger m_logger;
  private BaseMemory m_memory;
  private int m_page;
  private int m_cursorX = 0;
  private int m_cursorY = 0;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    this.m_spectrum = paramBaseSpectrum;
    this.m_logger = paramILogger;
    this.m_screenChanged = new boolean[6144];
    this.m_inkTable = new int[''];
    this.m_paperTable = new int[''];
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 8; j++)
        for (int k = 0; k < 8; k++)
        {
          this.m_inkTable[((i << 6) + (j << 3) + k)] = (k + (i << 3));
          this.m_paperTable[((i << 6) + (j << 3) + k)] = (j + (i << 3));
        }
    this.m_memory = this.m_spectrum.getMemory();
    setScale(this.m_spectrum.getScale());
    setSize(getPreferredSize());
    addKeyListener(this.m_spectrum.getKeyboard());
    this.m_page = 9;
  }

  public void reset()
  {
    for (int i = 0; i < 6144; i++)
      this.m_screenChanged[i] = true;
    this.m_screenDirty = true;
    this.m_borderColor = 7;
    this.m_borderDirty = true;
  }

  public void terminate()
  {
    this.m_memory = null;
    this.m_screenChanged = null;
    this.m_inkTable = null;
    this.m_paperTable = null;
    this.m_offscreenBorder = null;
    this.m_offscreenBorderGraphics = null;
    this.m_offscreenImage = null;
    this.m_offscreenImageGraphics = null;
    this.m_spectrum = null;
  }

  public int getPage()
  {
    return this.m_page;
  }

  public void setPage(int paramInt)
  {
    this.m_page = paramInt;
  }

  protected void setScale(int paramInt)
  {
    this.m_scale = paramInt;
    this.m_screenWidth = (256 * this.m_scale);
    this.m_screenHeight = (192 * this.m_scale);
    this.m_fullWidth = (this.m_screenWidth + 60 * this.m_scale);
    this.m_fullHeight = (this.m_screenHeight + 60 * this.m_scale);
  }

  public Dimension getMinimumSize()
  {
    return new Dimension(this.m_fullWidth, this.m_fullHeight);
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(this.m_fullWidth, this.m_fullHeight);
  }

  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }

  public void paint(Graphics paramGraphics)
  {
    PerformanceCounter.start("paint");
    if (this.m_offscreenBorder == null)
    {
      this.m_offscreenBorder = createCompatibleImage(this.m_fullWidth, this.m_fullHeight);
      this.m_offscreenBorderGraphics = this.m_offscreenBorder.getGraphics();
    }
    if (this.m_offscreenImage == null)
    {
      this.m_offscreenImage = createCompatibleImage(this.m_screenWidth, this.m_screenHeight);
      this.m_offscreenImageGraphics = this.m_offscreenImage.getGraphics();
    }
    if (this.m_borderDirty)
    {
      this.m_offscreenBorderGraphics.setColor(s_colorPalette[this.m_borderColor]);
      this.m_offscreenBorderGraphics.fillRect(0, 0, this.m_fullWidth, this.m_fullHeight);
      this.m_borderDirty = false;
      this.m_screenDirty = true;
    }
    if (this.m_screenDirty)
    {
      PerformanceCounter.start("paint-0-render");
      startRender();
      byte[] arrayOfByte = this.m_memory.getBytes(this.m_page);
      for (int i = 0; i < 6144; i++)
        if (this.m_screenChanged[i] != 0)
        {
          this.m_screenChanged[i] = false;
          int j = (i & 0x1F) << 3;
          int k = ((i & 0xE0) >> 2) + ((i & 0x700) >> 8) + ((i & 0x1800) >> 5);
          int m = arrayOfByte[i];
          int n = arrayOfByte[(6144 + ((j >> 3) + ((k & 0xF8) << 2)))] & 0xFF;
          draw8(j, k, m, n);
        }
      endRender();
      PerformanceCounter.end("paint-0-render");
      PerformanceCounter.start("paint-1-draw");
      this.m_offscreenBorderGraphics.drawImage(this.m_offscreenImage, 30 * this.m_scale, 30 * this.m_scale, null);
      PerformanceCounter.end("paint-1-draw");
      this.m_screenDirty = false;
    }
    PerformanceCounter.start("paint-2-draw");
    paramGraphics.drawImage(this.m_offscreenBorder, 0, 0, null);
    PerformanceCounter.end("paint-2-draw");
    PerformanceCounter.end("paint");
  }

  protected Image createCompatibleImage(int paramInt1, int paramInt2)
  {
    return createImage(paramInt1, paramInt2);
  }

  protected void startRender()
  {
  }

  protected void endRender()
  {
  }

  protected abstract void draw8(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public void flash()
  {
    this.m_flashPhase = (!this.m_flashPhase);
    byte[] arrayOfByte = this.m_memory.getBytes(this.m_page);
    int i = 0;
    for (int j = 6144; i < 768; j++)
    {
      int k = arrayOfByte[j] & 0xFF;
      if ((k & 0x80) != 0)
        attrTouch(j);
      i++;
    }
  }

  public void attrTouch(int paramInt)
  {
    paramInt = ((paramInt & 0x300) << 3) + (paramInt & 0xFF);
    int i = 0;
    while (i < 8)
    {
      screenTouch(paramInt);
      i++;
      paramInt += 256;
    }
  }

  public void screenTouch(int paramInt)
  {
    this.m_screenChanged[(paramInt & 0x3FFF)] = true;
    this.m_screenDirty = true;
  }

  public void setBorderColor(int paramInt)
  {
    this.m_borderColor = paramInt;
    this.m_borderDirty = true;
  }

  private int cursorToPixelAddr16(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= 32) || (paramInt2 < 0) || (paramInt2 >= 24))
      throw new IllegalArgumentException("Invalid coordinates: " + paramInt1 + "," + paramInt2);
    paramInt2 *= 8;
    return 16384 + (paramInt2 >> 6) * 2048 + ((paramInt2 & 0x3F) >> 3) * 32 + (paramInt2 & 0x7) * 256 + paramInt1;
  }

  private int cursorToAttrAddr16(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= 32) || (paramInt2 < 0) || (paramInt2 >= 24))
      throw new IllegalArgumentException("Invalid coordinates: " + paramInt1 + "," + paramInt2);
    return 22528 + paramInt2 * 32 + paramInt1;
  }

  public void setCursor(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= 32) || (paramInt2 < 0) || (paramInt2 >= 24))
      throw new IllegalArgumentException("Invalid coordinates: " + paramInt1 + "," + paramInt2);
    this.m_cursorX = paramInt1;
    this.m_cursorY = paramInt2;
  }

  public int getCursorX()
  {
    return this.m_cursorX;
  }

  public int getCursorY()
  {
    return this.m_cursorY;
  }

  public void clear(int paramInt)
  {
    setCursor(0, 0);
    clear(32, 24, paramInt);
  }

  public void clear(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = this.m_cursorX;
    int j = this.m_cursorY;
    for (int k = j; k < paramInt2; k++)
      for (int m = i; m < paramInt1; m++)
      {
        setCursor(m, k);
        print(' ', paramInt3);
      }
    setCursor(i, j);
  }

  public void print(char paramChar, int paramInt)
  {
    if ((this.m_cursorX < 32) && (this.m_cursorY < 24))
    {
      int i = cursorToPixelAddr16(this.m_cursorX, this.m_cursorY);
      if ((paramChar < ' ') || (paramChar > ''))
        paramChar = '?';
      int j = this.CHARSET_ADDR + (paramChar - ' ') * 8;
      this.m_memory.write8(cursorToAttrAddr16(this.m_cursorX, this.m_cursorY), paramInt);
      for (int k = 0; k < 8; k++)
      {
        this.m_memory.write8(i, this.m_memory.read8(j));
        i += 256;
        j++;
      }
      this.m_cursorX += 1;
    }
  }

  public void println(char paramChar, int paramInt)
  {
    int i = this.m_cursorX;
    int j = this.m_cursorY;
    print(paramChar, paramInt);
    setCursor(i, j + 1);
  }

  public void print(String paramString, int paramInt)
  {
    for (int i = 0; i < paramString.length(); i++)
      print(paramString.charAt(i), paramInt);
  }

  public void println(String paramString, int paramInt)
  {
    int i = this.m_cursorX;
    int j = this.m_cursorY;
    print(paramString, paramInt);
    setCursor(i, j + 1);
  }

  public void load(BaseLoader paramBaseLoader)
  {
  }

  public static BaseScreen getInstance()
  {
    String str = System.getProperty("java.version");
    if (str.startsWith("1.1"))
      return new ScreenJava1();
    return new ScreenJava2();
  }

  public void dumpScreenshot()
  {
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseScreen
 * JD-Core Version:    0.6.2
 */