package org.razvan.jzx;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Label;
import java.awt.Panel;

public abstract class BaseSpectrum extends BaseComponent
{
  public static final long FREQUENCY_MS = 19L;
  public static final int ISSUE_2 = 2;
  public static final int ISSUE_3 = 3;
  protected Label m_status;
  protected Z80 m_cpu;
  protected BaseMemory m_memory;
  protected BaseIO m_io;
  protected BaseScreen m_screen;
  protected Container m_container;
  protected BaseKeyboard m_keyboard;
  protected Clock m_clock;
  protected long m_frequency = 19L;
  protected int m_issue = 3;
  protected int m_vline;
  protected int m_scale = 1;
  protected int m_tvLines;
  protected int m_cyclesLine;
  private int m_frames;
  private int m_interrupts;
  private long m_fpsTimer = System.currentTimeMillis();

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_clock = new Clock(this.m_frequency, paramILogger);
    this.m_cpu.init(this.m_spectrum, paramILogger);
    this.m_memory.init(this.m_spectrum, paramILogger);
    this.m_io.init(this.m_spectrum, paramILogger);
    this.m_screen.init(this.m_spectrum, paramILogger);
    this.m_keyboard.init(this.m_spectrum, paramILogger);
    this.m_container = new Panel();
    this.m_container.setLayout(new BorderLayout());
    this.m_status = new Label();
    this.m_container.add(this.m_screen, "Center");
    this.m_container.add(this.m_status, "South");
  }

  public void reset()
  {
    this.m_cpu.reset();
    this.m_memory.reset();
    this.m_io.reset();
    this.m_screen.reset();
    this.m_keyboard.reset();
  }

  public void terminate()
  {
    this.m_keyboard.terminate();
    this.m_io.terminate();
    this.m_screen.terminate();
    this.m_memory.terminate();
    this.m_cpu.terminate();
    this.m_status = null;
    this.m_keyboard = null;
    this.m_screen = null;
    this.m_io = null;
    this.m_memory = null;
    this.m_cpu = null;
    this.m_clock = null;
    super.terminate();
  }

  public int getIssue()
  {
    return this.m_issue;
  }

  public int getScale()
  {
    return this.m_scale;
  }

  public void setScale(int paramInt)
  {
    this.m_scale = paramInt;
  }

  public int getVline()
  {
    return this.m_vline;
  }

  public long getFrequency()
  {
    return this.m_frequency;
  }

  public void setFrequency(long paramLong)
  {
    if (paramLong <= 0L)
      throw new IllegalArgumentException("Invalid frequency: " + paramLong);
    this.m_frequency = paramLong;
    this.m_clock.setFrequency(paramLong);
  }

  public Z80 getCPU()
  {
    return this.m_cpu;
  }

  public BaseMemory getMemory()
  {
    return this.m_memory;
  }

  public BaseIO getIO()
  {
    return this.m_io;
  }

  public BaseScreen getScreen()
  {
    return this.m_screen;
  }

  public Component getContainer()
  {
    return this.m_container;
  }

  public BaseKeyboard getKeyboard()
  {
    return this.m_keyboard;
  }

  public abstract String getMode();

  public void emulate()
  {
    this.m_clock.start();
    this.m_cpu.emulate();
    this.m_clock.end();
  }

  public void update()
  {
    int i = this.m_cpu.getTStates();
    if (i >= this.m_cyclesLine)
    {
      i -= this.m_cyclesLine;
      this.m_cpu.setTStates(i);
      this.m_io.advance(this.m_cyclesLine);
      if (++this.m_vline == this.m_tvLines)
      {
        this.m_vline = 0;
        this.m_frames += 1;
        long l1 = System.currentTimeMillis() - this.m_fpsTimer;
        if (l1 > 1000L)
        {
          long l2 = this.m_frames * 1000L / l1;
          this.m_status.setText("FPS: " + l2);
          this.m_fpsTimer = System.currentTimeMillis();
          this.m_frames = 0;
        }
        this.m_interrupts += 1;
        if (this.m_interrupts == 25)
        {
          this.m_interrupts = 0;
          this.m_screen.flash();
        }
        this.m_screen.repaint();
        synchronized (this.m_clock)
        {
          while (!this.m_clock.interrupted)
            try
            {
              this.m_clock.wait();
            }
            catch (InterruptedException localInterruptedException)
            {
              this.m_logger.log(0, localInterruptedException);
            }
          this.m_clock.interrupted = false;
        }
        this.m_cpu.interrupt();
      }
    }
  }

  public void pause()
  {
    this.m_cpu.pause();
  }

  public void unpause()
  {
    this.m_cpu.unpause();
  }

  public void stop()
  {
    this.m_cpu.stop();
  }

  public void load(BaseLoader paramBaseLoader)
  {
    this.m_cpu.load(paramBaseLoader);
    this.m_memory.load(paramBaseLoader);
    this.m_io.load(paramBaseLoader);
    this.m_screen.load(paramBaseLoader);
    this.m_keyboard.load(paramBaseLoader);
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.BaseSpectrum
 * JD-Core Version:    0.6.2
 */