package org.razvan.jzx;

public class Clock extends Thread
{
  public volatile boolean interrupted;
  private volatile long m_frequency;
  private volatile boolean m_stop;
  private ILogger m_logger;

  public Clock(long paramLong, ILogger paramILogger)
  {
    super("ClockThread");
    setDaemon(true);
    setPriority(8);
    this.m_frequency = paramLong;
    this.m_logger = paramILogger;
  }

  public long getFrequency()
  {
    return this.m_frequency;
  }

  public void setFrequency(long paramLong)
  {
    if (paramLong <= 0L)
      throw new IllegalArgumentException("Invalid frequency: " + paramLong);
    this.m_frequency = paramLong;
  }

  public void run()
  {
    while (true)
    {
      PerformanceCounter.start("clock");
      PerformanceCounter.start("clock-0-sleep");
      try
      {
        Thread.sleep(this.m_frequency);
      }
      catch (InterruptedException localInterruptedException)
      {
        this.m_logger.log(1, localInterruptedException);
      }
      PerformanceCounter.end("clock-0-sleep");
      if (this.m_stop)
        return;
      PerformanceCounter.start("clock-1-notify");
      synchronized (this)
      {
        this.interrupted = true;
        notifyAll();
      }
      PerformanceCounter.end("clock-1-notify");
      PerformanceCounter.end("clock");
    }
  }

  public void end()
  {
    this.m_stop = true;
    interrupt();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.Clock
 * JD-Core Version:    0.6.2
 */