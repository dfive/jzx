package org.razvan.jzx;

import java.io.PrintStream;

public class ConsoleLogger
  implements ILogger
{
  public void log(int paramInt, String paramString)
  {
    System.err.println("Channel: " + paramInt + ", " + paramString);
  }

  public void log(int paramInt, Throwable paramThrowable)
  {
    System.out.println("Channel: " + paramInt);
    paramThrowable.printStackTrace(System.out);
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.ConsoleLogger
 * JD-Core Version:    0.6.2
 */