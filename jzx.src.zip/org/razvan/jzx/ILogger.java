package org.razvan.jzx;

public abstract interface ILogger
{
  public static final int C_ERROR = 0;
  public static final int C_DEBUG = 1;

  public abstract void log(int paramInt, String paramString);

  public abstract void log(int paramInt, Throwable paramThrowable);
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.ILogger
 * JD-Core Version:    0.6.2
 */