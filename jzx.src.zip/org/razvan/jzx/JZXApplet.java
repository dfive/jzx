package org.razvan.jzx;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Container;
import java.io.IOException;

public class JZXApplet extends Applet
  implements Runnable
{
  private static final String SCALE_PARAMETER = "SCALE";
  private static final String MODE_PARAMETER = "MODE";
  private static final String SNAPSHOT_PARAMETER = "SNAPSHOT";
  private static final String MODE_48 = "48";
  private static final String MODE_128 = "128";
  private BaseSpectrum m_spectrum;

  public String[][] getParameterInfo()
  {
    return new String[][] { { "SCALE", "1-3", "Scale the screen size by 'x'" }, { "MODE", "48 or 128", "Hardware mode: 48k or 128k" }, { "SNAPSHOT", "URI", "Codebase-relative URI to Z80 snapshot" } };
  }

  public void init()
  {
    setLayout(new BorderLayout());
    AppletLogger localAppletLogger = new AppletLogger(this);
    Z80Loader localZ80Loader = null;
    int i = 1;
    try
    {
      String str1 = getParameter("SCALE");
      if (str1 != null)
        i = Integer.parseInt(str1);
      if ((i < 1) || (i > 3))
        i = 1;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      localAppletLogger.log(1, localNumberFormatException);
    }
    String str2 = getParameter("SNAPSHOT");
    if (str2 != null)
      try
      {
        localZ80Loader = new Z80Loader(localAppletLogger, getCodeBase());
        localZ80Loader.load(str2);
        if (localZ80Loader.getMode() == 0)
          this.m_spectrum = new org.razvan.jzx.v48.Spectrum();
        else if (localZ80Loader.getMode() == 1)
          this.m_spectrum = new org.razvan.jzx.v128.Spectrum();
        else
          localAppletLogger.log(0, "Unknown hardware mode: " + localZ80Loader.getMode());
      }
      catch (IOException localIOException)
      {
        localAppletLogger.log(0, localIOException);
      }
    if (this.m_spectrum == null)
    {
      String str3 = getParameter("MODE");
      if (str3 == null)
        str3 = "48";
      if (str3.equals("128"))
        this.m_spectrum = new org.razvan.jzx.v128.Spectrum();
      else
        this.m_spectrum = new org.razvan.jzx.v48.Spectrum();
    }
    this.m_spectrum.setScale(i);
    this.m_spectrum.init(this.m_spectrum, localAppletLogger);
    add(this.m_spectrum.getContainer());
    this.m_spectrum.reset();
    if (localZ80Loader != null)
      this.m_spectrum.load(localZ80Loader);
    this.m_spectrum.pause();
    new Thread(this).start();
  }

  public void run()
  {
    this.m_spectrum.emulate();
  }

  public void start()
  {
    this.m_spectrum.unpause();
  }

  public void stop()
  {
    this.m_spectrum.pause();
  }

  public void destroy()
  {
    this.m_spectrum.stop();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.JZXApplet
 * JD-Core Version:    0.6.2
 */