package org.razvan.jzx;

import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class JZXFrame
{
  private static final String SCALE_PARAMETER = "-scale";
  private static final String MODE_PARAMETER = "-mode";
  private static final String SNAPSHOT_PARAMETER = "-snapshot";
  private static final String MODE_48 = "48";
  private static final String MODE_128 = "128";

  private static String getParameter(String[] paramArrayOfString, String paramString)
  {
    for (int i = 0; i < paramArrayOfString.length - 1; i++)
      if (paramArrayOfString[i].equalsIgnoreCase(paramString))
        return paramArrayOfString[(i + 1)];
    return null;
  }

  public static void main(String[] paramArrayOfString)
  {
    Frame localFrame = new Frame("JZXFrame");
    localFrame.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        PerformanceCounter.report();
        System.exit(0);
      }
    });
    ConsoleLogger localConsoleLogger = new ConsoleLogger();
    Object localObject = null;
    Z80Loader localZ80Loader = null;
    URL localURL = null;
    try
    {
      String str1 = System.getProperty("user.dir").replace('\\', '/') + "/";
      if (str1.startsWith("/"))
        localURL = new URL("file:" + str1);
      else
        localURL = new URL("file:/" + str1);
    }
    catch (MalformedURLException localMalformedURLException)
    {
      localConsoleLogger.log(0, localMalformedURLException);
      System.exit(1);
    }
    int i = 1;
    try
    {
      String str2 = getParameter(paramArrayOfString, "-scale");
      if (str2 != null)
        i = Integer.parseInt(str2);
      if ((i < 1) || (i > 3))
        i = 1;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      localConsoleLogger.log(1, localNumberFormatException);
    }
    String str3 = getParameter(paramArrayOfString, "-snapshot");
    if (str3 != null)
      try
      {
        localZ80Loader = new Z80Loader(localConsoleLogger, localURL);
        localZ80Loader.load(str3);
        if (localZ80Loader.getMode() == 0)
          localObject = new org.razvan.jzx.v48.Spectrum();
        else if (localZ80Loader.getMode() == 1)
          localObject = new org.razvan.jzx.v128.Spectrum();
        else
          localConsoleLogger.log(0, "Unknown hardware mode: " + localZ80Loader.getMode());
      }
      catch (IOException localIOException)
      {
        localConsoleLogger.log(0, localIOException);
      }
    if (localObject == null)
    {
      String str4 = getParameter(paramArrayOfString, "-mode");
      if (str4 == null)
        str4 = "48";
      if (str4.equals("128"))
        localObject = new org.razvan.jzx.v128.Spectrum();
      else
        localObject = new org.razvan.jzx.v48.Spectrum();
    }
    ((BaseSpectrum)localObject).setScale(i);
    ((BaseSpectrum)localObject).init((BaseSpectrum)localObject, localConsoleLogger);
    localFrame.add(((BaseSpectrum)localObject).getContainer());
    localFrame.pack();
    localFrame.setVisible(true);
    ((BaseSpectrum)localObject).reset();
    if (localZ80Loader != null)
      ((BaseSpectrum)localObject).load(localZ80Loader);
    ((BaseSpectrum)localObject).emulate();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.JZXFrame
 * JD-Core Version:    0.6.2
 */