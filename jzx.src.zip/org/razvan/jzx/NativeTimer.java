package org.razvan.jzx;

import java.io.PrintStream;

public class NativeTimer
{
  private static boolean s_native = true;

  public static final long currentTimeNanos()
  {
    if (s_native)
      return nativeCurrentTimeNanos();
    return ()(System.currentTimeMillis() * 1000000.0D);
  }

  private static final native long nativeCurrentTimeNanos();

  static
  {
    try
    {
      System.loadLibrary("NativeTimer");
    }
    catch (Throwable localThrowable)
    {
      System.err.println("Failed to load NativeTimer: " + localThrowable.getMessage());
      s_native = false;
    }
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.NativeTimer
 * JD-Core Version:    0.6.2
 */