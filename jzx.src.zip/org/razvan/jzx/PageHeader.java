package org.razvan.jzx;

import java.io.IOException;
import java.io.InputStream;

class PageHeader
{
  private byte[] m_pageLength = new byte[2];
  private byte m_pageNumber;

  public void load(InputStream paramInputStream)
    throws IOException
  {
    this.m_pageLength[0] = ((byte)paramInputStream.read());
    this.m_pageLength[1] = ((byte)paramInputStream.read());
    this.m_pageNumber = ((byte)paramInputStream.read());
  }

  public int getPageLength()
  {
    return (this.m_pageLength[1] & 0xFF) << 8 | this.m_pageLength[0] & 0xFF;
  }

  public int getPageNumber()
  {
    return this.m_pageNumber & 0xFF;
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.PageHeader
 * JD-Core Version:    0.6.2
 */