package org.razvan.jzx;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;

public class PerformanceCounter
{
  private static boolean s_enable = false;
  private static int s_warmup = 50;
  private static Hashtable s_startTimes = new Hashtable();
  private static Hashtable s_timePairs = new Hashtable();

  public static void setEnable(boolean paramBoolean)
  {
    s_enable = paramBoolean;
  }

  public static void setWarmup(int paramInt)
  {
    if (paramInt < 0)
      throw new IllegalArgumentException("Invalid warmup count: " + paramInt);
    s_warmup = paramInt;
  }

  public static synchronized void start(String paramString)
  {
    if (!s_enable)
      return;
    if (s_startTimes.containsKey(paramString))
      throw new IllegalArgumentException("Timer '" + paramString + "' already started");
    long l = NativeTimer.currentTimeNanos();
    s_startTimes.put(paramString, new Double(l / 1000.0D));
  }

  public static synchronized void end(String paramString)
  {
    if (!s_enable)
      return;
    long l = NativeTimer.currentTimeNanos();
    if (!s_startTimes.containsKey(paramString))
      throw new IllegalArgumentException("Timer '" + paramString + "' not already started");
    double d = ((Double)s_startTimes.remove(paramString)).doubleValue();
    Pair localPair;
    if (s_timePairs.containsKey(paramString))
    {
      localPair = (Pair)s_timePairs.get(paramString);
    }
    else
    {
      localPair = new Pair(null);
      s_timePairs.put(paramString, localPair);
    }
    localPair.count += 1;
    if (localPair.count > s_warmup)
      localPair.time += l / 1000.0D - d;
  }

  public static synchronized void report()
  {
    if (!s_enable)
      return;
    Enumeration localEnumeration = s_timePairs.keys();
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      Pair localPair = (Pair)s_timePairs.get(str);
      int i = localPair.count - s_warmup;
      System.out.println(str + "=" + localPair.time / i + " (" + i + ")");
    }
  }

  private static class Pair
  {
    double time;
    int count;

    private Pair()
    {
    }

    Pair(PerformanceCounter.1 param1)
    {
      this();
    }
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.PerformanceCounter
 * JD-Core Version:    0.6.2
 */