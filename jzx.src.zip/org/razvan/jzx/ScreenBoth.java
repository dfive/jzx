package org.razvan.jzx;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.image.MemoryImageSource;

public class ScreenBoth extends BaseScreen
{
  private int[] m_data;
  private MemoryImageSource m_memoryImageSource;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_data = new int[this.m_screenWidth * this.m_screenHeight];
    this.m_memoryImageSource = new MemoryImageSource(this.m_screenWidth, this.m_screenHeight, this.m_data, 0, this.m_screenWidth);
    this.m_memoryImageSource.setAnimated(true);
  }

  protected void setScale(int paramInt)
  {
    super.setScale(paramInt);
    this.m_data = new int[this.m_screenWidth * this.m_screenHeight];
    this.m_memoryImageSource = new MemoryImageSource(this.m_screenWidth, this.m_screenHeight, this.m_data, 0, this.m_screenWidth);
    this.m_memoryImageSource.setAnimated(true);
  }

  public void paint(Graphics paramGraphics)
  {
    if (this.m_offscreenImage == null)
    {
      this.m_offscreenImage = createImage(this.m_memoryImageSource);
      this.m_offscreenImageGraphics = null;
    }
    super.paint(paramGraphics);
  }

  protected void draw8(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((this.m_flashPhase) && ((paramInt4 & 0x80) != 0))
      paramInt4 = paramInt4 & 0xC0 | (paramInt4 ^ 0xFFFFFFFF) & 0x3F;
    int i = this.m_inkTable[(paramInt4 & 0xFFFFFF7F)];
    int j = this.m_paperTable[(paramInt4 & 0xFFFFFF7F)];
    int k = paramInt1 * this.m_scale + paramInt2 * this.m_scale * this.m_screenWidth;
    int m = 0;
    while (m < 8 * this.m_scale)
    {
      int n = 0xFF000000 | BaseScreen.s_rgbPalette[j];
      for (int i1 = 0; i1 < this.m_scale; i1++)
      {
        this.m_data[(k++)] = n;
        m++;
      }
      paramInt3 <<= 1;
    }
    k = paramInt1 * this.m_scale + paramInt2 * this.m_scale * this.m_screenWidth;
    for (m = 1; m < this.m_scale; m++)
      System.arraycopy(this.m_data, k, this.m_data, k + m * this.m_screenWidth, 8 * this.m_scale);
  }

  protected void endRender()
  {
    this.m_memoryImageSource.newPixels();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.ScreenBoth
 * JD-Core Version:    0.6.2
 */