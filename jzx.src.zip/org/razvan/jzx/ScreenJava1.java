package org.razvan.jzx;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;

public class ScreenJava1 extends BaseScreen
{
  private static final int IMAGE_CACHE_SIZE = 900;
  private Image[] m_imageMap;
  private int m_count;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_imageMap = new Image[2048];
  }

  protected Image getImage(int paramInt1, int paramInt2)
  {
    if ((this.m_flashPhase) && ((paramInt2 & 0x80) != 0))
      paramInt2 = paramInt2 & 0xC0 | (paramInt2 ^ 0xFFFFFFFF) & 0x3F;
    paramInt2 &= -129;
    int i = paramInt1 << 7 | paramInt2;
    Image localImage = this.m_imageMap[i];
    if (localImage == null)
    {
      if (this.m_count > 900)
        while (true)
        {
          int j = (int)(Math.random() * this.m_imageMap.length);
          if (this.m_imageMap[j] != null)
          {
            localImage = this.m_imageMap[j];
            this.m_imageMap[j] = null;
            break;
          }
        }
      localImage = createImage(4 * this.m_scale, 1 * this.m_scale);
      this.m_count += 1;
      Graphics localGraphics = localImage.getGraphics();
      int k = this.m_inkTable[paramInt2];
      int m = this.m_paperTable[paramInt2];
      for (int n = 0; n < 4; n++)
      {
        localGraphics.setColor(BaseScreen.s_colorPalette[m]);
        localGraphics.fillRect(n * this.m_scale, 0, 1 * this.m_scale, 1 * this.m_scale);
        paramInt1 <<= 1;
      }
      this.m_imageMap[i] = localImage;
    }
    return localImage;
  }

  protected void draw8(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Image localImage = getImage((paramInt3 & 0xF0) >> 4, paramInt4);
    this.m_offscreenImageGraphics.drawImage(localImage, paramInt1 * this.m_scale, paramInt2 * this.m_scale, this);
    localImage = getImage(paramInt3 & 0xF, paramInt4);
    this.m_offscreenImageGraphics.drawImage(localImage, (paramInt1 + 4) * this.m_scale, paramInt2 * this.m_scale, this);
  }

  public void terminate()
  {
    this.m_imageMap = null;
    super.terminate();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.ScreenJava1
 * JD-Core Version:    0.6.2
 */