package org.razvan.jzx;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferInt;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ScreenJava2 extends BaseScreen
{
  private int m_pix8Width;
  private int m_pix8Height;
  private int[] m_segment;
  private BufferedImage m_bufferedOffscreenImage;
  private DataBuffer m_buffer;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_pix8Width = (8 * this.m_scale);
    this.m_pix8Height = this.m_scale;
    this.m_segment = new int[this.m_pix8Width * this.m_pix8Height];
  }

  protected void setScale(int paramInt)
  {
    super.setScale(paramInt);
    this.m_pix8Width = (8 * this.m_scale);
    this.m_pix8Height = this.m_scale;
    this.m_segment = new int[this.m_pix8Width * this.m_pix8Height];
  }

  protected Image createCompatibleImage(int paramInt1, int paramInt2)
  {
    this.m_bufferedOffscreenImage = ((BufferedImage)super.createCompatibleImage(paramInt1, paramInt2));
    this.m_buffer = this.m_bufferedOffscreenImage.getRaster().getDataBuffer();
    return this.m_bufferedOffscreenImage;
  }

  protected void draw8(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt1 * this.m_scale;
    int j = paramInt2 * this.m_scale;
    if ((this.m_flashPhase) && ((paramInt4 & 0x80) != 0))
      paramInt4 = paramInt4 & 0xC0 | (paramInt4 ^ 0xFFFFFFFF) & 0x3F;
    int k = this.m_inkTable[(paramInt4 & 0xFFFFFF7F)];
    int m = this.m_paperTable[(paramInt4 & 0xFFFFFF7F)];
    int[] arrayOfInt;
    int i1;
    int n;
    int i2;
    if ((this.m_buffer instanceof DataBufferInt))
    {
      arrayOfInt = ((DataBufferInt)this.m_buffer).getBankData()[0];
      i1 = this.m_screenWidth;
      n = j * i1 + i;
      i2 = 0;
    }
    else
    {
      arrayOfInt = this.m_segment;
      i1 = this.m_pix8Width;
      n = 0;
      i2 = 1;
    }
    int i3 = 0;
    while (i3 < this.m_pix8Width)
    {
      int i4 = BaseScreen.s_rgbPalette[m];
      for (int i5 = 0; i5 < this.m_scale; i5++)
        arrayOfInt[(n + i3++)] = i4;
      paramInt3 <<= 1;
    }
    for (i3 = 1; i3 < this.m_pix8Height; i3++)
      System.arraycopy(arrayOfInt, n, arrayOfInt, n + i3 * i1, this.m_pix8Width);
    if (i2 != 0)
      this.m_bufferedOffscreenImage.setRGB(i, j, this.m_pix8Width, this.m_pix8Height, this.m_segment, 0, this.m_pix8Width);
  }

  public void dumpScreenshot()
  {
    try
    {
      File localFile = new File("screenshot-" + System.currentTimeMillis() + ".png");
      ImageIO.write(this.m_bufferedOffscreenImage, "png", localFile);
    }
    catch (IOException localIOException)
    {
      this.m_logger.log(0, "Failed to save screenshot: " + localIOException.getMessage());
    }
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.ScreenJava2
 * JD-Core Version:    0.6.2
 */