package org.razvan.jzx;

class SnapshotMemory extends BaseMemory
{
  public void reset()
  {
    for (int i = 0; i <= 11; i++)
      for (int j = 0; j < 16384; j++)
        this.m_page[i][j] = ((byte)(int)(Math.random() * 256.0D));
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.SnapshotMemory
 * JD-Core Version:    0.6.2
 */