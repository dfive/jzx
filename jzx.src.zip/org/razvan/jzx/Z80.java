package org.razvan.jzx;

public class Z80 extends BaseComponent
{
  protected volatile boolean m_stop;
  protected volatile boolean m_pause;
  private int m_tstates;
  private BaseMemory m_memory;
  private BaseIO m_io;
  private static final int CARRY_MASK = 1;
  private static final int ONE_MASK = 1;
  private static final int ADDSUBTRACT_MASK = 2;
  private static final int PARITY_MASK = 4;
  private static final int OVERFLOW_MASK = 4;
  private static final int THREE_MASK = 8;
  private static final int HALFCARRY_MASK = 16;
  private static final int FIVE_MASK = 32;
  private static final int ZERO_MASK = 64;
  private static final int SIGN_MASK = 128;
  private boolean m_carryF;
  private boolean m_addsubtractF;
  private boolean m_parityoverflowF;
  private boolean m_halfcarryF;
  private boolean m_zeroF;
  private boolean m_signF;
  private boolean m_5F;
  private boolean m_3F;
  private int m_a8;
  private int m_f8;
  private int m_b8;
  private int m_c8;
  private int m_d8;
  private int m_e8;
  private int m_h8;
  private int m_l8;
  private int m_af16alt;
  private int m_bc16alt;
  private int m_de16alt;
  private int m_hl16alt;
  private int m_ix16;
  private int m_iy16;
  private int m_xx16;
  private int m_sp16;
  private int m_pc16;
  private int m_r8;
  private int m_i8;
  private int m_im2;
  private int m_iff1a;
  private int m_iff1b;
  private int m_x8;
  private static final boolean[] m_parityTable = { true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true };
  private static boolean[] m_halfcarryTable = { false, false, true, false, true, false, true, true };
  private static boolean[] m_subhalfcarryTable = { false, true, true, true, false, false, false, true };
  private static boolean[] m_overflowTable = { false, true, false, false, false, false, true, false };
  private static boolean[] m_suboverflowTable = { false, false, false, true, true, false, false, false };

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_memory = this.m_spectrum.getMemory();
    this.m_io = this.m_spectrum.getIO();
  }

  public void reset()
  {
    this.m_pc16 = 0;
    this.m_i8 = 0;
    this.m_r8 = 0;
    this.m_im2 = 0;
    this.m_iff1a = 0;
    this.m_iff1b = 0;
  }

  public void terminate()
  {
  }

  public void interrupt()
  {
    if (this.m_iff1a != 0)
    {
      if (this.m_memory.read8(this.m_pc16) == 118)
        inc16pc();
      this.m_iff1a = 0;
      this.m_iff1b = 0;
      push(this.m_pc16);
      if (this.m_im2 == 2)
      {
        this.m_tstates += 19;
        this.m_pc16 = this.m_memory.read16(this.m_i8 << 8 | 0xFF);
      }
      else
      {
        this.m_tstates += 13;
        this.m_pc16 = 56;
      }
    }
  }

  public void nmi()
  {
    this.m_tstates += 15;
    this.m_iff1b = this.m_iff1a;
    this.m_iff1a = 0;
    if (this.m_memory.read8(this.m_pc16) == 118)
      inc16pc();
    push(this.m_pc16);
    this.m_pc16 = 102;
  }

  public int getTStates()
  {
    return this.m_tstates;
  }

  public void setTStates(int paramInt)
  {
    this.m_tstates = paramInt;
  }

  public void addTStates(int paramInt)
  {
    this.m_tstates += paramInt;
  }

  private int af16()
  {
    return this.m_a8 << 8 | this.m_f8;
  }

  private int bc16()
  {
    return this.m_b8 << 8 | this.m_c8;
  }

  private int de16()
  {
    return this.m_d8 << 8 | this.m_e8;
  }

  private int hl16()
  {
    return this.m_h8 << 8 | this.m_l8;
  }

  private void af16(int paramInt)
  {
    this.m_a8 = (paramInt >> 8);
    this.m_f8 = (paramInt & 0xFF);
  }

  private void bc16(int paramInt)
  {
    this.m_b8 = (paramInt >> 8);
    this.m_c8 = (paramInt & 0xFF);
  }

  private void de16(int paramInt)
  {
    this.m_d8 = (paramInt >> 8);
    this.m_e8 = (paramInt & 0xFF);
  }

  private void hl16(int paramInt)
  {
    this.m_h8 = (paramInt >> 8);
    this.m_l8 = (paramInt & 0xFF);
  }

  private int xx16low8()
  {
    return this.m_xx16 & 0xFF;
  }

  private int xx16high8()
  {
    return this.m_xx16 >> 8;
  }

  private void xx16low8(int paramInt)
  {
    this.m_xx16 = (this.m_xx16 & 0xFF00 | paramInt);
  }

  private void xx16high8(int paramInt)
  {
    this.m_xx16 = (paramInt << 8 | this.m_xx16 & 0xFF);
  }

  private void storeFlags()
  {
    if (this.m_signF)
      this.m_f8 |= 128;
    else
      this.m_f8 &= -129;
    if (this.m_zeroF)
      this.m_f8 |= 64;
    else
      this.m_f8 &= -65;
    if (this.m_halfcarryF)
      this.m_f8 |= 16;
    else
      this.m_f8 &= -17;
    if (this.m_parityoverflowF)
      this.m_f8 |= 4;
    else
      this.m_f8 &= -5;
    if (this.m_addsubtractF)
      this.m_f8 |= 2;
    else
      this.m_f8 &= -3;
    if (this.m_carryF)
      this.m_f8 |= 1;
    else
      this.m_f8 &= -2;
    if (this.m_3F)
      this.m_f8 |= 8;
    else
      this.m_f8 &= -9;
    if (this.m_5F)
      this.m_f8 |= 32;
    else
      this.m_f8 &= -33;
  }

  private void retrieveFlags()
  {
    this.m_signF = ((this.m_f8 & 0x80) != 0);
    this.m_zeroF = ((this.m_f8 & 0x40) != 0);
    this.m_halfcarryF = ((this.m_f8 & 0x10) != 0);
    this.m_parityoverflowF = ((this.m_f8 & 0x4) != 0);
    this.m_addsubtractF = ((this.m_f8 & 0x2) != 0);
    this.m_carryF = ((this.m_f8 & 0x1) != 0);
    this.m_3F = ((this.m_f8 & 0x8) != 0);
    this.m_5F = ((this.m_f8 & 0x20) != 0);
  }

  private int inc16pc()
  {
    int i = this.m_pc16;
    this.m_pc16 = (this.m_pc16 + 1 & 0xFFFF);
    return i;
  }

  private int inc16sp()
  {
    int i = this.m_sp16;
    this.m_sp16 = (this.m_sp16 + 1 & 0xFFFF);
    return i;
  }

  private int inc16bc()
  {
    int i = bc16();
    bc16(i + 1 & 0xFFFF);
    return i;
  }

  private int inc16de()
  {
    int i = de16();
    de16(i + 1 & 0xFFFF);
    return i;
  }

  private int inc16hl()
  {
    int i = hl16();
    hl16(i + 1 & 0xFFFF);
    return i;
  }

  private int inc16xx()
  {
    int i = this.m_xx16;
    this.m_xx16 = (this.m_xx16 + 1 & 0xFFFF);
    return i;
  }

  private int dec16pc()
  {
    int i = this.m_pc16;
    this.m_pc16 = (this.m_pc16 - 1 & 0xFFFF);
    return i;
  }

  private int dec16sp()
  {
    int i = this.m_sp16;
    this.m_sp16 = (this.m_sp16 - 1 & 0xFFFF);
    return i;
  }

  private int dec16bc()
  {
    int i = bc16();
    bc16(i - 1 & 0xFFFF);
    return i;
  }

  private int dec16de()
  {
    int i = de16();
    de16(i - 1 & 0xFFFF);
    return i;
  }

  private int dec16hl()
  {
    int i = hl16();
    hl16(i - 1 & 0xFFFF);
    return i;
  }

  private int dec16xx()
  {
    int i = this.m_xx16;
    this.m_xx16 = (this.m_xx16 - 1 & 0xFFFF);
    return i;
  }

  private void add_xx(int paramInt)
  {
    int i = this.m_xx16 + paramInt;
    int j = (this.m_xx16 & 0x800) >> 9 | (paramInt & 0x800) >> 10 | (i & 0x800) >> 11;
    this.m_xx16 = (i & 0xFFFF);
    this.m_halfcarryF = m_halfcarryTable[j];
    this.m_addsubtractF = false;
    this.m_carryF = ((i & 0x10000) != 0);
    int k = this.m_xx16 >> 8;
    this.m_3F = ((k & 0x8) != 0);
    this.m_5F = ((k & 0x20) != 0);
  }

  private void add_hl(int paramInt)
  {
    this.m_x8 = this.m_h8;
    int i = hl16();
    int j = i + paramInt;
    int k = (i & 0x800) >> 9 | (paramInt & 0x800) >> 10 | (j & 0x800) >> 11;
    hl16(j & 0xFFFF);
    this.m_halfcarryF = m_halfcarryTable[k];
    this.m_addsubtractF = false;
    this.m_carryF = ((j & 0x10000) != 0);
    this.m_3F = ((this.m_h8 & 0x8) != 0);
    this.m_5F = ((this.m_h8 & 0x20) != 0);
  }

  private void adc_hl(int paramInt)
  {
    int i = hl16();
    int j = i + paramInt + (this.m_carryF ? 1 : 0);
    int k = (i & 0x8800) >> 9 | (paramInt & 0x8800) >> 10 | (j & 0x8800) >> 11;
    i = j & 0xFFFF;
    hl16(i);
    this.m_signF = ((i & 0x8000) != 0);
    this.m_zeroF = (i == 0);
    this.m_halfcarryF = m_halfcarryTable[(k & 0x7)];
    this.m_parityoverflowF = m_overflowTable[(k >> 4)];
    this.m_addsubtractF = false;
    this.m_carryF = ((j & 0x10000) != 0);
    this.m_3F = ((this.m_h8 & 0x8) != 0);
    this.m_5F = ((this.m_h8 & 0x20) != 0);
  }

  private void sbc_hl(int paramInt)
  {
    int i = hl16();
    int j = i - paramInt - (this.m_carryF ? 1 : 0);
    int k = (i & 0x8800) >> 9 | (paramInt & 0x8800) >> 10 | (j & 0x8800) >> 11;
    i = j & 0xFFFF;
    hl16(i);
    this.m_signF = ((i & 0x8000) != 0);
    this.m_zeroF = (i == 0);
    this.m_halfcarryF = m_subhalfcarryTable[(k & 0x7)];
    this.m_parityoverflowF = m_suboverflowTable[(k >> 4)];
    this.m_addsubtractF = true;
    this.m_carryF = ((j & 0x10000) != 0);
    this.m_3F = ((this.m_h8 & 0x8) != 0);
    this.m_5F = ((this.m_h8 & 0x20) != 0);
  }

  private int add16(int paramInt1, int paramInt2)
  {
    return paramInt1 + paramInt2 & 0xFFFF;
  }

  private int sub16(int paramInt1, int paramInt2)
  {
    return paramInt1 - paramInt2 & 0xFFFF;
  }

  private int inc16(int paramInt)
  {
    return paramInt + 1 & 0xFFFF;
  }

  private int incinc16(int paramInt)
  {
    return paramInt + 2 & 0xFFFF;
  }

  private int dec16(int paramInt)
  {
    return paramInt - 1 & 0xFFFF;
  }

  private int decdec16(int paramInt)
  {
    return paramInt - 2 & 0xFFFF;
  }

  private int inc8(int paramInt)
  {
    int i = paramInt + 1 & 0xFF;
    this.m_signF = ((i & 0x80) != 0);
    this.m_zeroF = (i == 0);
    this.m_halfcarryF = ((i & 0xF) == 0);
    this.m_parityoverflowF = (i == 128);
    this.m_addsubtractF = false;
    this.m_3F = ((i & 0x8) != 0);
    this.m_5F = ((i & 0x20) != 0);
    return i;
  }

  private int dec8(int paramInt)
  {
    int i = paramInt - 1 & 0xFF;
    this.m_signF = ((i & 0x80) != 0);
    this.m_zeroF = (i == 0);
    this.m_halfcarryF = ((i & 0xF) == 15);
    this.m_parityoverflowF = (i == 127);
    this.m_addsubtractF = true;
    this.m_3F = ((i & 0x8) != 0);
    this.m_5F = ((i & 0x20) != 0);
    return i;
  }

  private int rlc8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x80) != 0);
    int i = (paramInt << 1 | (this.m_carryF ? 1 : 0)) & 0xFF;
    shift_test(i);
    return i;
  }

  private int rrc8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x1) != 0);
    int i = paramInt >> 1 | (this.m_carryF ? 1 : 0) << 7;
    shift_test(i);
    return i;
  }

  private int rl8(int paramInt)
  {
    boolean bool = (paramInt & 0x80) != 0;
    int i = (paramInt << 1 | (this.m_carryF ? 1 : 0)) & 0xFF;
    this.m_carryF = bool;
    shift_test(i);
    return i;
  }

  private int rr8(int paramInt)
  {
    boolean bool = (paramInt & 0x1) != 0;
    int i = paramInt >> 1 | (this.m_carryF ? 1 : 0) << 7;
    this.m_carryF = bool;
    shift_test(i);
    return i;
  }

  private int sla8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x80) != 0);
    int i = paramInt << 1 & 0xFF;
    shift_test(i);
    return i;
  }

  private int sra8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x1) != 0);
    int i = paramInt & 0x80;
    i = paramInt >> 1 | i;
    shift_test(i);
    return i;
  }

  private int sli8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x80) != 0);
    int i = (paramInt << 1 | 0x1) & 0xFF;
    shift_test(i);
    return i;
  }

  private int srl8(int paramInt)
  {
    this.m_carryF = ((paramInt & 0x1) != 0);
    int i = paramInt >> 1;
    shift_test(i);
    return i;
  }

  private void shift_test(int paramInt)
  {
    this.m_signF = ((paramInt & 0x80) != 0);
    this.m_zeroF = (paramInt == 0);
    this.m_halfcarryF = false;
    this.m_parityoverflowF = m_parityTable[paramInt];
    this.m_addsubtractF = false;
    this.m_3F = ((paramInt & 0x8) != 0);
    this.m_5F = ((paramInt & 0x20) != 0);
  }

  private int pop16()
  {
    int i = this.m_memory.read16(this.m_sp16);
    this.m_sp16 = incinc16(this.m_sp16);
    return i;
  }

  private void push(int paramInt)
  {
    this.m_sp16 = decdec16(this.m_sp16);
    this.m_memory.write16(this.m_sp16, paramInt);
  }

  private void ld_a_special(int paramInt)
  {
    this.m_a8 = paramInt;
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = false;
    this.m_parityoverflowF = (this.m_iff1b != 0);
    this.m_addsubtractF = false;
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void add_a(int paramInt)
  {
    int i = this.m_a8 + paramInt;
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_a8 = (i & 0xFF);
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = m_halfcarryTable[(j & 0x7)];
    this.m_parityoverflowF = m_overflowTable[(j >> 4)];
    this.m_addsubtractF = false;
    this.m_carryF = ((i & 0x100) != 0);
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void adc_a(int paramInt)
  {
    int i = this.m_a8 + paramInt + (this.m_carryF ? 1 : 0);
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_a8 = (i & 0xFF);
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = m_halfcarryTable[(j & 0x7)];
    this.m_parityoverflowF = m_overflowTable[(j >> 4)];
    this.m_addsubtractF = false;
    this.m_carryF = ((i & 0x100) != 0);
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void sub_a(int paramInt)
  {
    int i = this.m_a8 - paramInt;
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_a8 = (i & 0xFF);
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = m_subhalfcarryTable[(j & 0x7)];
    this.m_parityoverflowF = m_suboverflowTable[(j >> 4)];
    this.m_addsubtractF = true;
    this.m_carryF = ((i & 0x100) != 0);
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void sbc_a(int paramInt)
  {
    int i = this.m_a8 - paramInt - (this.m_carryF ? 1 : 0);
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_a8 = (i & 0xFF);
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = m_subhalfcarryTable[(j & 0x7)];
    this.m_parityoverflowF = m_suboverflowTable[(j >> 4)];
    this.m_addsubtractF = true;
    this.m_carryF = ((i & 0x100) != 0);
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void and_a(int paramInt)
  {
    this.m_a8 &= paramInt;
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = true;
    this.m_parityoverflowF = m_parityTable[this.m_a8];
    this.m_addsubtractF = false;
    this.m_carryF = false;
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void xor_a(int paramInt)
  {
    this.m_a8 ^= paramInt;
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = false;
    this.m_parityoverflowF = m_parityTable[this.m_a8];
    this.m_addsubtractF = false;
    this.m_carryF = false;
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void or_a(int paramInt)
  {
    this.m_a8 |= paramInt;
    this.m_signF = ((this.m_a8 & 0x80) != 0);
    this.m_zeroF = (this.m_a8 == 0);
    this.m_halfcarryF = false;
    this.m_parityoverflowF = m_parityTable[this.m_a8];
    this.m_addsubtractF = false;
    this.m_carryF = false;
    this.m_3F = ((this.m_a8 & 0x8) != 0);
    this.m_5F = ((this.m_a8 & 0x20) != 0);
  }

  private void cmp_a(int paramInt)
  {
    int i = this.m_a8 - paramInt;
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_signF = ((i & 0x80) != 0);
    this.m_zeroF = ((i & 0xFF) == 0);
    this.m_halfcarryF = m_subhalfcarryTable[(j & 0x7)];
    this.m_parityoverflowF = m_suboverflowTable[(j >> 4)];
    this.m_addsubtractF = true;
    this.m_carryF = ((i & 0x100) != 0);
    this.m_3F = ((paramInt & 0x8) != 0);
    this.m_5F = ((paramInt & 0x20) != 0);
  }

  private void cmp_a_special(int paramInt)
  {
    int i = this.m_a8 - paramInt;
    int j = (this.m_a8 & 0x88) >> 1 | (paramInt & 0x88) >> 2 | (i & 0x88) >> 3;
    this.m_signF = ((i & 0x80) != 0);
    this.m_zeroF = ((i & 0xFF) == 0);
    this.m_halfcarryF = m_subhalfcarryTable[(j & 0x7)];
    this.m_addsubtractF = true;
  }

  private void bit(int paramInt1, int paramInt2)
  {
    this.m_zeroF = ((paramInt2 & 1 << paramInt1) == 0);
    this.m_halfcarryF = true;
    this.m_parityoverflowF = this.m_zeroF;
    this.m_addsubtractF = false;
    this.m_signF = ((paramInt2 & 1 << paramInt1) == 128);
    this.m_3F = ((paramInt1 == 3) && (!this.m_zeroF));
    this.m_5F = ((paramInt1 == 5) && (!this.m_zeroF));
  }

  private void bit_hl(int paramInt1, int paramInt2)
  {
    this.m_zeroF = ((paramInt2 & 1 << paramInt1) == 0);
    this.m_halfcarryF = true;
    this.m_parityoverflowF = this.m_zeroF;
    this.m_addsubtractF = false;
    this.m_signF = ((paramInt2 & 1 << paramInt1) == 128);
    this.m_3F = ((this.m_x8 & 0x8) != 0);
    this.m_5F = ((this.m_x8 & 0x20) != 0);
  }

  private void bit_xx(int paramInt1, int paramInt2)
  {
    this.m_zeroF = ((paramInt2 & 1 << paramInt1) == 0);
    this.m_halfcarryF = true;
    this.m_parityoverflowF = this.m_zeroF;
    this.m_addsubtractF = false;
    this.m_signF = ((paramInt2 & 1 << paramInt1) == 128);
    this.m_3F = ((xx16high8() & 0x8) != 0);
    this.m_5F = ((xx16high8() & 0x20) != 0);
  }

  private int in8(int paramInt)
  {
    int i = this.m_io.in8(paramInt);
    this.m_signF = ((i & 0x80) != 0);
    this.m_zeroF = (i == 0);
    this.m_halfcarryF = false;
    this.m_parityoverflowF = m_parityTable[i];
    this.m_addsubtractF = false;
    this.m_3F = ((i & 0x8) != 0);
    this.m_5F = ((i & 0x20) != 0);
    return i;
  }

  private int mone8()
  {
    this.m_r8 = (this.m_r8 & 0x80 | this.m_r8 + 1 & 0x7F);
    return this.m_memory.read8(inc16pc());
  }

  public void stop()
  {
    this.m_stop = true;
  }

  public void pause()
  {
    synchronized (this)
    {
      this.m_pause = true;
      notifyAll();
    }
  }

  public void unpause()
  {
    synchronized (this)
    {
      this.m_pause = false;
      notifyAll();
    }
  }

  public void emulate()
  {
    while (true)
    {
      this.m_spectrum.update();
      int i = 0;
      int j = 0;
      int k = mone8();
      switch (k)
      {
      case 0:
        this.m_tstates += 4;
        break;
      case 1:
        this.m_tstates += 10;
        bc16(this.m_memory.read16(this.m_pc16));
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 2:
        this.m_tstates += 7;
        this.m_memory.write8(bc16(), this.m_a8);
        break;
      case 3:
        this.m_tstates += 6;
        inc16bc();
        break;
      case 4:
        this.m_tstates += 4;
        this.m_b8 = inc8(this.m_b8);
        break;
      case 5:
        this.m_tstates += 4;
        this.m_b8 = dec8(this.m_b8);
        break;
      case 6:
        this.m_tstates += 7;
        this.m_b8 = this.m_memory.read8(inc16pc());
        break;
      case 7:
        this.m_tstates += 4;
        this.m_carryF = ((this.m_a8 & 0x80) != 0);
        this.m_a8 = ((this.m_a8 << 1 | (this.m_carryF ? 1 : 0)) & 0xFF);
        this.m_halfcarryF = false;
        this.m_addsubtractF = false;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 8:
        this.m_tstates += 4;
        storeFlags();
        i = af16();
        af16(this.m_af16alt);
        this.m_af16alt = i;
        retrieveFlags();
        break;
      case 9:
        this.m_tstates += 11;
        add_hl(bc16());
        break;
      case 10:
        this.m_tstates += 7;
        this.m_a8 = this.m_memory.read8(bc16());
        break;
      case 11:
        this.m_tstates += 6;
        dec16bc();
        break;
      case 12:
        this.m_tstates += 4;
        this.m_c8 = inc8(this.m_c8);
        break;
      case 13:
        this.m_tstates += 4;
        this.m_c8 = dec8(this.m_c8);
        break;
      case 14:
        this.m_tstates += 7;
        this.m_c8 = this.m_memory.read8(inc16pc());
        break;
      case 15:
        this.m_tstates += 4;
        this.m_carryF = ((this.m_a8 & 0x1) != 0);
        this.m_a8 = (this.m_a8 >> 1 | (this.m_carryF ? 1 : 0) << 7);
        this.m_halfcarryF = false;
        this.m_addsubtractF = false;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 16:
        this.m_b8 = (this.m_b8 - 1 & 0xFF);
        if (this.m_b8 != 0)
        {
          this.m_tstates += 13;
          this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        }
        else
        {
          this.m_tstates += 8;
          inc16pc();
        }
        break;
      case 17:
        this.m_tstates += 10;
        de16(this.m_memory.read16(this.m_pc16));
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 18:
        this.m_tstates += 7;
        this.m_memory.write8(de16(), this.m_a8);
        break;
      case 19:
        this.m_tstates += 6;
        inc16de();
        break;
      case 20:
        this.m_tstates += 4;
        this.m_d8 = inc8(this.m_d8);
        break;
      case 21:
        this.m_tstates += 4;
        this.m_d8 = dec8(this.m_d8);
        break;
      case 22:
        this.m_tstates += 7;
        this.m_d8 = this.m_memory.read8(inc16pc());
        break;
      case 23:
        this.m_tstates += 4;
        j = this.m_carryF ? 1 : 0;
        this.m_carryF = ((this.m_a8 & 0x80) != 0);
        this.m_a8 = ((this.m_a8 << 1 | j) & 0xFF);
        this.m_halfcarryF = false;
        this.m_addsubtractF = false;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 24:
        this.m_tstates += 12;
        this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        this.m_x8 = (this.m_pc16 >> 8);
        break;
      case 25:
        this.m_tstates += 11;
        add_hl(de16());
        break;
      case 26:
        this.m_tstates += 7;
        this.m_a8 = this.m_memory.read8(de16());
        break;
      case 27:
        this.m_tstates += 6;
        dec16de();
        break;
      case 28:
        this.m_tstates += 4;
        this.m_e8 = inc8(this.m_e8);
        break;
      case 29:
        this.m_tstates += 4;
        this.m_e8 = dec8(this.m_e8);
        break;
      case 30:
        this.m_tstates += 7;
        this.m_e8 = this.m_memory.read8(inc16pc());
        break;
      case 31:
        this.m_tstates += 4;
        j = this.m_carryF ? 1 : 0;
        this.m_carryF = ((this.m_a8 & 0x1) != 0);
        this.m_a8 = (this.m_a8 >> 1 | j << 7);
        this.m_halfcarryF = false;
        this.m_addsubtractF = false;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 32:
        if (!this.m_zeroF)
        {
          this.m_tstates += 12;
          this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        }
        else
        {
          this.m_tstates += 7;
          inc16pc();
        }
        break;
      case 33:
        this.m_tstates += 10;
        hl16(this.m_memory.read16(this.m_pc16));
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 34:
        this.m_tstates += 16;
        this.m_memory.write16(this.m_memory.read16(this.m_pc16), hl16());
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 35:
        this.m_tstates += 6;
        inc16hl();
        break;
      case 36:
        this.m_tstates += 4;
        this.m_h8 = inc8(this.m_h8);
        break;
      case 37:
        this.m_tstates += 4;
        this.m_h8 = dec8(this.m_h8);
        break;
      case 38:
        this.m_tstates += 7;
        this.m_h8 = this.m_memory.read8(inc16pc());
        break;
      case 39:
        this.m_tstates += 4;
        boolean bool1 = this.m_carryF;
        boolean bool2 = this.m_addsubtractF;
        if (!bool2)
        {
          j = 0;
          if ((this.m_halfcarryF) || ((this.m_a8 & 0xF) > 9))
            j = 6;
          if ((this.m_carryF) || (this.m_a8 >> 4 > 9) || ((this.m_a8 >> 4 >= 9) && ((this.m_a8 & 0xF) > 9)))
          {
            j |= 96;
            bool1 = true;
          }
        }
        else if (this.m_carryF)
        {
          j = this.m_halfcarryF ? 154 : 160;
        }
        else
        {
          j = this.m_halfcarryF ? 250 : 0;
        }
        add_a(j);
        this.m_addsubtractF = bool2;
        this.m_parityoverflowF = m_parityTable[this.m_a8];
        this.m_carryF = bool1;
        break;
      case 40:
        if (this.m_zeroF)
        {
          this.m_tstates += 12;
          this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        }
        else
        {
          this.m_tstates += 7;
          inc16pc();
        }
        break;
      case 41:
        this.m_tstates += 11;
        add_hl(hl16());
        break;
      case 42:
        this.m_tstates += 16;
        hl16(this.m_memory.read16(this.m_memory.read16(this.m_pc16)));
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 43:
        this.m_tstates += 6;
        dec16hl();
        break;
      case 44:
        this.m_tstates += 4;
        this.m_l8 = inc8(this.m_l8);
        break;
      case 45:
        this.m_tstates += 4;
        this.m_l8 = dec8(this.m_l8);
        break;
      case 46:
        this.m_tstates += 7;
        this.m_l8 = this.m_memory.read8(inc16pc());
        break;
      case 47:
        this.m_tstates += 4;
        this.m_a8 ^= 255;
        this.m_halfcarryF = true;
        this.m_addsubtractF = true;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 48:
        if (!this.m_carryF)
        {
          this.m_tstates += 12;
          this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        }
        else
        {
          this.m_tstates += 7;
          inc16pc();
        }
        break;
      case 49:
        this.m_tstates += 10;
        this.m_sp16 = this.m_memory.read16(this.m_pc16);
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 50:
        this.m_tstates += 13;
        this.m_memory.write8(this.m_memory.read16(this.m_pc16), this.m_a8);
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 51:
        this.m_tstates += 6;
        inc16sp();
        break;
      case 52:
        this.m_tstates += 11;
        j = this.m_memory.read8(hl16());
        j = inc8(j);
        this.m_memory.write8(hl16(), j);
        break;
      case 53:
        this.m_tstates += 11;
        j = this.m_memory.read8(hl16());
        j = dec8(j);
        this.m_memory.write8(hl16(), j);
        break;
      case 54:
        this.m_tstates += 10;
        this.m_memory.write8(hl16(), this.m_memory.read8(inc16pc()));
        break;
      case 55:
        this.m_tstates += 4;
        this.m_halfcarryF = false;
        this.m_addsubtractF = false;
        this.m_carryF = true;
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 56:
        if (this.m_carryF)
        {
          this.m_tstates += 12;
          this.m_pc16 = add16(this.m_pc16, (byte)this.m_memory.read8(this.m_pc16) + 1);
        }
        else
        {
          this.m_tstates += 7;
          inc16pc();
        }
        break;
      case 57:
        this.m_tstates += 11;
        add_hl(this.m_sp16);
        break;
      case 58:
        this.m_tstates += 13;
        this.m_a8 = this.m_memory.read8(this.m_memory.read16(this.m_pc16));
        this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 59:
        this.m_tstates += 6;
        dec16sp();
        break;
      case 60:
        this.m_tstates += 4;
        this.m_a8 = inc8(this.m_a8);
        break;
      case 61:
        this.m_tstates += 4;
        this.m_a8 = dec8(this.m_a8);
        break;
      case 62:
        this.m_tstates += 7;
        this.m_a8 = this.m_memory.read8(inc16pc());
        break;
      case 63:
        this.m_tstates += 4;
        this.m_halfcarryF = this.m_carryF;
        this.m_addsubtractF = false;
        this.m_carryF = (!this.m_carryF);
        this.m_3F = ((this.m_a8 & 0x8) != 0);
        this.m_5F = ((this.m_a8 & 0x20) != 0);
        break;
      case 64:
        this.m_tstates += 4;
        break;
      case 65:
        this.m_tstates += 4;
        this.m_b8 = this.m_c8;
        break;
      case 66:
        this.m_tstates += 4;
        this.m_b8 = this.m_d8;
        break;
      case 67:
        this.m_tstates += 4;
        this.m_b8 = this.m_e8;
        break;
      case 68:
        this.m_tstates += 4;
        this.m_b8 = this.m_h8;
        break;
      case 69:
        this.m_tstates += 4;
        this.m_b8 = this.m_l8;
        break;
      case 70:
        this.m_tstates += 7;
        this.m_b8 = this.m_memory.read8(hl16());
        break;
      case 71:
        this.m_tstates += 4;
        this.m_b8 = this.m_a8;
        break;
      case 72:
        this.m_tstates += 4;
        this.m_c8 = this.m_b8;
        break;
      case 73:
        this.m_tstates += 4;
        break;
      case 74:
        this.m_tstates += 4;
        this.m_c8 = this.m_d8;
        break;
      case 75:
        this.m_tstates += 4;
        this.m_c8 = this.m_e8;
        break;
      case 76:
        this.m_tstates += 4;
        this.m_c8 = this.m_h8;
        break;
      case 77:
        this.m_tstates += 4;
        this.m_c8 = this.m_l8;
        break;
      case 78:
        this.m_tstates += 7;
        this.m_c8 = this.m_memory.read8(hl16());
        break;
      case 79:
        this.m_tstates += 4;
        this.m_c8 = this.m_a8;
        break;
      case 80:
        this.m_tstates += 4;
        this.m_d8 = this.m_b8;
        break;
      case 81:
        this.m_tstates += 4;
        this.m_d8 = this.m_c8;
        break;
      case 82:
        this.m_tstates += 4;
        break;
      case 83:
        this.m_tstates += 4;
        this.m_d8 = this.m_e8;
        break;
      case 84:
        this.m_tstates += 4;
        this.m_d8 = this.m_h8;
        break;
      case 85:
        this.m_tstates += 4;
        this.m_d8 = this.m_l8;
        break;
      case 86:
        this.m_tstates += 7;
        this.m_d8 = this.m_memory.read8(hl16());
        break;
      case 87:
        this.m_tstates += 4;
        this.m_d8 = this.m_a8;
        break;
      case 88:
        this.m_tstates += 4;
        this.m_e8 = this.m_b8;
        break;
      case 89:
        this.m_tstates += 4;
        this.m_e8 = this.m_c8;
        break;
      case 90:
        this.m_tstates += 4;
        this.m_e8 = this.m_d8;
        break;
      case 91:
        this.m_tstates += 4;
        break;
      case 92:
        this.m_tstates += 4;
        this.m_e8 = this.m_h8;
        break;
      case 93:
        this.m_tstates += 4;
        this.m_e8 = this.m_l8;
        break;
      case 94:
        this.m_tstates += 7;
        this.m_e8 = this.m_memory.read8(hl16());
        break;
      case 95:
        this.m_tstates += 4;
        this.m_e8 = this.m_a8;
        break;
      case 96:
        this.m_tstates += 4;
        this.m_h8 = this.m_b8;
        break;
      case 97:
        this.m_tstates += 4;
        this.m_h8 = this.m_c8;
        break;
      case 98:
        this.m_tstates += 4;
        this.m_h8 = this.m_d8;
        break;
      case 99:
        this.m_tstates += 4;
        this.m_h8 = this.m_e8;
        break;
      case 100:
        this.m_tstates += 4;
        break;
      case 101:
        this.m_tstates += 4;
        this.m_h8 = this.m_l8;
        break;
      case 102:
        this.m_tstates += 7;
        this.m_h8 = this.m_memory.read8(hl16());
        break;
      case 103:
        this.m_tstates += 4;
        this.m_h8 = this.m_a8;
        break;
      case 104:
        this.m_tstates += 4;
        this.m_l8 = this.m_b8;
        break;
      case 105:
        this.m_tstates += 4;
        this.m_l8 = this.m_c8;
        break;
      case 106:
        this.m_tstates += 4;
        this.m_l8 = this.m_d8;
        break;
      case 107:
        this.m_tstates += 4;
        this.m_l8 = this.m_e8;
        break;
      case 108:
        this.m_tstates += 4;
        this.m_l8 = this.m_h8;
        break;
      case 109:
        this.m_tstates += 4;
        break;
      case 110:
        this.m_tstates += 7;
        this.m_l8 = this.m_memory.read8(hl16());
        break;
      case 111:
        this.m_tstates += 4;
        this.m_l8 = this.m_a8;
        break;
      case 112:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_b8);
        break;
      case 113:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_c8);
        break;
      case 114:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_d8);
        break;
      case 115:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_e8);
        break;
      case 116:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_h8);
        break;
      case 117:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_l8);
        break;
      case 118:
        this.m_tstates += 4;
        dec16pc();
        break;
      case 119:
        this.m_tstates += 7;
        this.m_memory.write8(hl16(), this.m_a8);
        break;
      case 120:
        this.m_tstates += 4;
        this.m_a8 = this.m_b8;
        break;
      case 121:
        this.m_tstates += 4;
        this.m_a8 = this.m_c8;
        break;
      case 122:
        this.m_tstates += 4;
        this.m_a8 = this.m_d8;
        break;
      case 123:
        this.m_tstates += 4;
        this.m_a8 = this.m_e8;
        break;
      case 124:
        this.m_tstates += 4;
        this.m_a8 = this.m_h8;
        break;
      case 125:
        this.m_tstates += 4;
        this.m_a8 = this.m_l8;
        break;
      case 126:
        this.m_tstates += 7;
        this.m_a8 = this.m_memory.read8(hl16());
        break;
      case 127:
        this.m_tstates += 4;
        break;
      case 128:
        this.m_tstates += 4;
        add_a(this.m_b8);
        break;
      case 129:
        this.m_tstates += 4;
        add_a(this.m_c8);
        break;
      case 130:
        this.m_tstates += 4;
        add_a(this.m_d8);
        break;
      case 131:
        this.m_tstates += 4;
        add_a(this.m_e8);
        break;
      case 132:
        this.m_tstates += 4;
        add_a(this.m_h8);
        break;
      case 133:
        this.m_tstates += 4;
        add_a(this.m_l8);
        break;
      case 134:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        add_a(j);
        break;
      case 135:
        this.m_tstates += 4;
        add_a(this.m_a8);
        break;
      case 136:
        this.m_tstates += 4;
        adc_a(this.m_b8);
        break;
      case 137:
        this.m_tstates += 4;
        adc_a(this.m_c8);
        break;
      case 138:
        this.m_tstates += 4;
        adc_a(this.m_d8);
        break;
      case 139:
        this.m_tstates += 4;
        adc_a(this.m_e8);
        break;
      case 140:
        this.m_tstates += 4;
        adc_a(this.m_h8);
        break;
      case 141:
        this.m_tstates += 4;
        adc_a(this.m_l8);
        break;
      case 142:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        adc_a(j);
        break;
      case 143:
        this.m_tstates += 4;
        adc_a(this.m_a8);
        break;
      case 144:
        this.m_tstates += 4;
        sub_a(this.m_b8);
        break;
      case 145:
        this.m_tstates += 4;
        sub_a(this.m_c8);
        break;
      case 146:
        this.m_tstates += 4;
        sub_a(this.m_d8);
        break;
      case 147:
        this.m_tstates += 4;
        sub_a(this.m_e8);
        break;
      case 148:
        this.m_tstates += 4;
        sub_a(this.m_h8);
        break;
      case 149:
        this.m_tstates += 4;
        sub_a(this.m_l8);
        break;
      case 150:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        sub_a(j);
        break;
      case 151:
        this.m_tstates += 4;
        sub_a(this.m_a8);
        break;
      case 152:
        this.m_tstates += 4;
        sbc_a(this.m_b8);
        break;
      case 153:
        this.m_tstates += 4;
        sbc_a(this.m_c8);
        break;
      case 154:
        this.m_tstates += 4;
        sbc_a(this.m_d8);
        break;
      case 155:
        this.m_tstates += 4;
        sbc_a(this.m_e8);
        break;
      case 156:
        this.m_tstates += 4;
        sbc_a(this.m_h8);
        break;
      case 157:
        this.m_tstates += 4;
        sbc_a(this.m_l8);
        break;
      case 158:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        sbc_a(j);
        break;
      case 159:
        this.m_tstates += 4;
        sbc_a(this.m_a8);
        break;
      case 160:
        this.m_tstates += 4;
        and_a(this.m_b8);
        break;
      case 161:
        this.m_tstates += 4;
        and_a(this.m_c8);
        break;
      case 162:
        this.m_tstates += 4;
        and_a(this.m_d8);
        break;
      case 163:
        this.m_tstates += 4;
        and_a(this.m_e8);
        break;
      case 164:
        this.m_tstates += 4;
        and_a(this.m_h8);
        break;
      case 165:
        this.m_tstates += 4;
        and_a(this.m_l8);
        break;
      case 166:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        and_a(j);
        break;
      case 167:
        this.m_tstates += 4;
        and_a(this.m_a8);
        break;
      case 168:
        this.m_tstates += 4;
        xor_a(this.m_b8);
        break;
      case 169:
        this.m_tstates += 4;
        xor_a(this.m_c8);
        break;
      case 170:
        this.m_tstates += 4;
        xor_a(this.m_d8);
        break;
      case 171:
        this.m_tstates += 4;
        xor_a(this.m_e8);
        break;
      case 172:
        this.m_tstates += 4;
        xor_a(this.m_h8);
        break;
      case 173:
        this.m_tstates += 4;
        xor_a(this.m_l8);
        break;
      case 174:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        xor_a(j);
        break;
      case 175:
        this.m_tstates += 4;
        xor_a(this.m_a8);
        break;
      case 176:
        this.m_tstates += 4;
        or_a(this.m_b8);
        break;
      case 177:
        this.m_tstates += 4;
        or_a(this.m_c8);
        break;
      case 178:
        this.m_tstates += 4;
        or_a(this.m_d8);
        break;
      case 179:
        this.m_tstates += 4;
        or_a(this.m_e8);
        break;
      case 180:
        this.m_tstates += 4;
        or_a(this.m_h8);
        break;
      case 181:
        this.m_tstates += 4;
        or_a(this.m_l8);
        break;
      case 182:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        or_a(j);
        break;
      case 183:
        this.m_tstates += 4;
        or_a(this.m_a8);
        break;
      case 184:
        this.m_tstates += 4;
        cmp_a(this.m_b8);
        break;
      case 185:
        this.m_tstates += 4;
        cmp_a(this.m_c8);
        break;
      case 186:
        this.m_tstates += 4;
        cmp_a(this.m_d8);
        break;
      case 187:
        this.m_tstates += 4;
        cmp_a(this.m_e8);
        break;
      case 188:
        this.m_tstates += 4;
        cmp_a(this.m_h8);
        break;
      case 189:
        this.m_tstates += 4;
        cmp_a(this.m_l8);
        break;
      case 190:
        this.m_tstates += 7;
        j = this.m_memory.read8(hl16());
        cmp_a(j);
        break;
      case 191:
        this.m_tstates += 4;
        cmp_a(this.m_a8);
        break;
      case 192:
        this.m_tstates += 5;
        if (!this.m_zeroF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 193:
        this.m_tstates += 10;
        bc16(pop16());
        break;
      case 194:
        this.m_tstates += 10;
        if (!this.m_zeroF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 195:
        this.m_tstates += 10;
        this.m_pc16 = this.m_memory.read16(this.m_pc16);
        break;
      case 196:
        if (!this.m_zeroF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 197:
        this.m_tstates += 11;
        push(bc16());
        break;
      case 198:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        add_a(j);
        break;
      case 199:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 0;
        break;
      case 200:
        this.m_tstates += 5;
        if (this.m_zeroF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 201:
        this.m_tstates += 10;
        this.m_pc16 = pop16();
        break;
      case 202:
        this.m_tstates += 10;
        if (this.m_zeroF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 203:
        k = mone8();
        decodeCB(k);
        break;
      case 204:
        if (this.m_zeroF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 205:
        this.m_tstates += 17;
        push(incinc16(this.m_pc16));
        this.m_pc16 = this.m_memory.read16(this.m_pc16);
        break;
      case 206:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        adc_a(j);
        break;
      case 207:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 8;
        break;
      case 208:
        this.m_tstates += 5;
        if (!this.m_carryF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 209:
        this.m_tstates += 10;
        de16(pop16());
        break;
      case 210:
        this.m_tstates += 10;
        if (!this.m_carryF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 211:
        this.m_tstates += 11;
        this.m_io.out(this.m_a8 << 8 | this.m_memory.read8(inc16pc()), this.m_a8);
        break;
      case 212:
        if (!this.m_carryF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 213:
        this.m_tstates += 11;
        push(de16());
        break;
      case 214:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        sub_a(j);
        break;
      case 215:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 16;
        break;
      case 216:
        this.m_tstates += 5;
        if (this.m_carryF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 217:
        this.m_tstates += 4;
        i = bc16();
        bc16(this.m_bc16alt);
        this.m_bc16alt = i;
        i = de16();
        de16(this.m_de16alt);
        this.m_de16alt = i;
        i = hl16();
        hl16(this.m_hl16alt);
        this.m_hl16alt = i;
        break;
      case 218:
        this.m_tstates += 10;
        if (this.m_carryF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 219:
        this.m_tstates += 11;
        this.m_a8 = this.m_io.in8(this.m_a8 << 8 | this.m_memory.read8(inc16pc()));
        break;
      case 220:
        if (this.m_carryF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 221:
        k = mone8();
        this.m_xx16 = this.m_ix16;
        decodeXX(k);
        this.m_ix16 = this.m_xx16;
        break;
      case 222:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        sbc_a(j);
        break;
      case 223:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 24;
        break;
      case 224:
        this.m_tstates += 5;
        if (!this.m_parityoverflowF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 225:
        this.m_tstates += 10;
        hl16(pop16());
        break;
      case 226:
        this.m_tstates += 10;
        if (!this.m_parityoverflowF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 227:
        this.m_tstates += 19;
        i = this.m_memory.read16(this.m_sp16);
        this.m_memory.write16(this.m_sp16, hl16());
        hl16(i);
        break;
      case 228:
        if (!this.m_parityoverflowF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 229:
        this.m_tstates += 11;
        push(hl16());
        break;
      case 230:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        and_a(j);
        break;
      case 231:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 32;
        break;
      case 232:
        this.m_tstates += 5;
        if (this.m_parityoverflowF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 233:
        this.m_tstates += 4;
        this.m_pc16 = hl16();
        break;
      case 234:
        this.m_tstates += 10;
        if (this.m_parityoverflowF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 235:
        this.m_tstates += 4;
        i = de16();
        de16(hl16());
        hl16(i);
        break;
      case 236:
        if (this.m_parityoverflowF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 237:
        k = mone8();
        decodeED(k);
        break;
      case 238:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        xor_a(j);
        break;
      case 239:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 40;
        break;
      case 240:
        this.m_tstates += 5;
        if (!this.m_signF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 241:
        this.m_tstates += 10;
        af16(pop16());
        retrieveFlags();
        break;
      case 242:
        this.m_tstates += 10;
        if (!this.m_signF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 243:
        this.m_tstates += 4;
        this.m_iff1a = 0;
        this.m_iff1b = 0;
        break;
      case 244:
        if (!this.m_signF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 245:
        this.m_tstates += 11;
        storeFlags();
        push(af16());
        break;
      case 246:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        or_a(j);
        break;
      case 247:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 48;
        break;
      case 248:
        this.m_tstates += 5;
        if (this.m_signF)
        {
          this.m_tstates += 6;
          this.m_pc16 = pop16();
        }
        break;
      case 249:
        this.m_tstates += 6;
        this.m_sp16 = hl16();
        break;
      case 250:
        this.m_tstates += 10;
        if (this.m_signF)
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        else
          this.m_pc16 = incinc16(this.m_pc16);
        break;
      case 251:
        this.m_tstates += 4;
        this.m_iff1a = 1;
        this.m_iff1b = 1;
        break;
      case 252:
        if (this.m_signF)
        {
          this.m_tstates += 17;
          push(incinc16(this.m_pc16));
          this.m_pc16 = this.m_memory.read16(this.m_pc16);
        }
        else
        {
          this.m_tstates += 10;
          this.m_pc16 = incinc16(this.m_pc16);
        }
        break;
      case 253:
        k = mone8();
        this.m_xx16 = this.m_iy16;
        decodeXX(k);
        this.m_iy16 = this.m_xx16;
        break;
      case 254:
        this.m_tstates += 7;
        j = this.m_memory.read8(inc16pc());
        cmp_a(j);
        break;
      case 255:
        this.m_tstates += 11;
        push(this.m_pc16);
        this.m_pc16 = 56;
      }
      if (this.m_stop)
        break;
      synchronized (this)
      {
        while (this.m_pause)
          try
          {
            wait();
          }
          catch (InterruptedException localInterruptedException)
          {
            this.m_logger.log(0, localInterruptedException);
          }
      }
    }
  }

  private void decodeCB(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    case 0:
      this.m_tstates += 8;
      this.m_b8 = rlc8(this.m_b8);
      break;
    case 1:
      this.m_tstates += 8;
      this.m_c8 = rlc8(this.m_c8);
      break;
    case 2:
      this.m_tstates += 8;
      this.m_d8 = rlc8(this.m_d8);
      break;
    case 3:
      this.m_tstates += 8;
      this.m_e8 = rlc8(this.m_e8);
      break;
    case 4:
      this.m_tstates += 8;
      this.m_h8 = rlc8(this.m_h8);
      break;
    case 5:
      this.m_tstates += 8;
      this.m_l8 = rlc8(this.m_l8);
      break;
    case 6:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = rlc8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 7:
      this.m_tstates += 8;
      this.m_a8 = rlc8(this.m_a8);
      break;
    case 8:
      this.m_tstates += 8;
      this.m_b8 = rrc8(this.m_b8);
      break;
    case 9:
      this.m_tstates += 8;
      this.m_c8 = rrc8(this.m_c8);
      break;
    case 10:
      this.m_tstates += 8;
      this.m_d8 = rrc8(this.m_d8);
      break;
    case 11:
      this.m_tstates += 8;
      this.m_e8 = rrc8(this.m_e8);
      break;
    case 12:
      this.m_tstates += 8;
      this.m_h8 = rrc8(this.m_h8);
      break;
    case 13:
      this.m_tstates += 8;
      this.m_l8 = rrc8(this.m_l8);
      break;
    case 14:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = rrc8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 15:
      this.m_tstates += 8;
      this.m_a8 = rrc8(this.m_a8);
      break;
    case 16:
      this.m_tstates += 8;
      this.m_b8 = rl8(this.m_b8);
      break;
    case 17:
      this.m_tstates += 8;
      this.m_c8 = rl8(this.m_c8);
      break;
    case 18:
      this.m_tstates += 8;
      this.m_d8 = rl8(this.m_d8);
      break;
    case 19:
      this.m_tstates += 8;
      this.m_e8 = rl8(this.m_e8);
      break;
    case 20:
      this.m_tstates += 8;
      this.m_h8 = rl8(this.m_h8);
      break;
    case 21:
      this.m_tstates += 8;
      this.m_l8 = rl8(this.m_l8);
      break;
    case 22:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = rl8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 23:
      this.m_tstates += 8;
      this.m_a8 = rl8(this.m_a8);
      break;
    case 24:
      this.m_tstates += 8;
      this.m_b8 = rr8(this.m_b8);
      break;
    case 25:
      this.m_tstates += 8;
      this.m_c8 = rr8(this.m_c8);
      break;
    case 26:
      this.m_tstates += 8;
      this.m_d8 = rr8(this.m_d8);
      break;
    case 27:
      this.m_tstates += 8;
      this.m_e8 = rr8(this.m_e8);
      break;
    case 28:
      this.m_tstates += 8;
      this.m_h8 = rr8(this.m_h8);
      break;
    case 29:
      this.m_tstates += 8;
      this.m_l8 = rr8(this.m_l8);
      break;
    case 30:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = rr8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 31:
      this.m_tstates += 8;
      this.m_a8 = rr8(this.m_a8);
      break;
    case 32:
      this.m_tstates += 8;
      this.m_b8 = sla8(this.m_b8);
      break;
    case 33:
      this.m_tstates += 8;
      this.m_c8 = sla8(this.m_c8);
      break;
    case 34:
      this.m_tstates += 8;
      this.m_d8 = sla8(this.m_d8);
      break;
    case 35:
      this.m_tstates += 8;
      this.m_e8 = sla8(this.m_e8);
      break;
    case 36:
      this.m_tstates += 8;
      this.m_h8 = sla8(this.m_h8);
      break;
    case 37:
      this.m_tstates += 8;
      this.m_l8 = sla8(this.m_l8);
      break;
    case 38:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = sla8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 39:
      this.m_tstates += 8;
      this.m_a8 = sla8(this.m_a8);
      break;
    case 40:
      this.m_tstates += 8;
      this.m_b8 = sra8(this.m_b8);
      break;
    case 41:
      this.m_tstates += 8;
      this.m_c8 = sra8(this.m_c8);
      break;
    case 42:
      this.m_tstates += 8;
      this.m_d8 = sra8(this.m_d8);
      break;
    case 43:
      this.m_tstates += 8;
      this.m_e8 = sra8(this.m_e8);
      break;
    case 44:
      this.m_tstates += 8;
      this.m_h8 = sra8(this.m_h8);
      break;
    case 45:
      this.m_tstates += 8;
      this.m_l8 = sra8(this.m_l8);
      break;
    case 46:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = sra8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 47:
      this.m_tstates += 8;
      this.m_a8 = sra8(this.m_a8);
      break;
    case 48:
      this.m_tstates += 8;
      this.m_b8 = sli8(this.m_b8);
      break;
    case 49:
      this.m_tstates += 8;
      this.m_c8 = sli8(this.m_c8);
      break;
    case 50:
      this.m_tstates += 8;
      this.m_d8 = sli8(this.m_d8);
      break;
    case 51:
      this.m_tstates += 8;
      this.m_e8 = sli8(this.m_e8);
      break;
    case 52:
      this.m_tstates += 8;
      this.m_h8 = sli8(this.m_h8);
      break;
    case 53:
      this.m_tstates += 8;
      this.m_l8 = sli8(this.m_l8);
      break;
    case 54:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = sli8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 55:
      this.m_tstates += 8;
      this.m_a8 = sli8(this.m_a8);
      break;
    case 56:
      this.m_tstates += 8;
      this.m_b8 = srl8(this.m_b8);
      break;
    case 57:
      this.m_tstates += 8;
      this.m_c8 = srl8(this.m_c8);
      break;
    case 58:
      this.m_tstates += 8;
      this.m_d8 = srl8(this.m_d8);
      break;
    case 59:
      this.m_tstates += 8;
      this.m_e8 = srl8(this.m_e8);
      break;
    case 60:
      this.m_tstates += 8;
      this.m_h8 = srl8(this.m_h8);
      break;
    case 61:
      this.m_tstates += 8;
      this.m_l8 = srl8(this.m_l8);
      break;
    case 62:
      this.m_tstates += 15;
      i = this.m_memory.read8(hl16());
      i = srl8(i);
      this.m_memory.write8(hl16(), i);
      break;
    case 63:
      this.m_tstates += 8;
      this.m_a8 = srl8(this.m_a8);
      break;
    case 64:
      this.m_tstates += 8;
      bit(0, this.m_b8);
      break;
    case 65:
      this.m_tstates += 8;
      bit(0, this.m_c8);
      break;
    case 66:
      this.m_tstates += 8;
      bit(0, this.m_d8);
      break;
    case 67:
      this.m_tstates += 8;
      bit(0, this.m_e8);
      break;
    case 68:
      this.m_tstates += 8;
      bit(0, this.m_h8);
      break;
    case 69:
      this.m_tstates += 8;
      bit(0, this.m_l8);
      break;
    case 70:
      this.m_tstates += 12;
      bit_hl(0, this.m_memory.read8(hl16()));
      break;
    case 71:
      this.m_tstates += 8;
      bit(0, this.m_a8);
      break;
    case 72:
      this.m_tstates += 8;
      bit(1, this.m_b8);
      break;
    case 73:
      this.m_tstates += 8;
      bit(1, this.m_c8);
      break;
    case 74:
      this.m_tstates += 8;
      bit(1, this.m_d8);
      break;
    case 75:
      this.m_tstates += 8;
      bit(1, this.m_e8);
      break;
    case 76:
      this.m_tstates += 8;
      bit(1, this.m_h8);
      break;
    case 77:
      this.m_tstates += 8;
      bit(1, this.m_l8);
      break;
    case 78:
      this.m_tstates += 12;
      bit_hl(1, this.m_memory.read8(hl16()));
      break;
    case 79:
      this.m_tstates += 8;
      bit(1, this.m_a8);
      break;
    case 80:
      this.m_tstates += 8;
      bit(2, this.m_b8);
      break;
    case 81:
      this.m_tstates += 8;
      bit(2, this.m_c8);
      break;
    case 82:
      this.m_tstates += 8;
      bit(2, this.m_d8);
      break;
    case 83:
      this.m_tstates += 8;
      bit(2, this.m_e8);
      break;
    case 84:
      this.m_tstates += 8;
      bit(2, this.m_h8);
      break;
    case 85:
      this.m_tstates += 8;
      bit(2, this.m_l8);
      break;
    case 86:
      this.m_tstates += 12;
      bit_hl(2, this.m_memory.read8(hl16()));
      break;
    case 87:
      this.m_tstates += 8;
      bit(2, this.m_a8);
      break;
    case 88:
      this.m_tstates += 8;
      bit(3, this.m_b8);
      break;
    case 89:
      this.m_tstates += 8;
      bit(3, this.m_c8);
      break;
    case 90:
      this.m_tstates += 8;
      bit(3, this.m_d8);
      break;
    case 91:
      this.m_tstates += 8;
      bit(3, this.m_e8);
      break;
    case 92:
      this.m_tstates += 8;
      bit(3, this.m_h8);
      break;
    case 93:
      this.m_tstates += 8;
      bit(3, this.m_l8);
      break;
    case 94:
      this.m_tstates += 12;
      bit_hl(3, this.m_memory.read8(hl16()));
      break;
    case 95:
      this.m_tstates += 8;
      bit(3, this.m_a8);
      break;
    case 96:
      this.m_tstates += 8;
      bit(4, this.m_b8);
      break;
    case 97:
      this.m_tstates += 8;
      bit(4, this.m_c8);
      break;
    case 98:
      this.m_tstates += 8;
      bit(4, this.m_d8);
      break;
    case 99:
      this.m_tstates += 8;
      bit(4, this.m_e8);
      break;
    case 100:
      this.m_tstates += 8;
      bit(4, this.m_h8);
      break;
    case 101:
      this.m_tstates += 8;
      bit(4, this.m_l8);
      break;
    case 102:
      this.m_tstates += 12;
      bit_hl(4, this.m_memory.read8(hl16()));
      break;
    case 103:
      this.m_tstates += 8;
      bit(4, this.m_a8);
      break;
    case 104:
      this.m_tstates += 8;
      bit(5, this.m_b8);
      break;
    case 105:
      this.m_tstates += 8;
      bit(5, this.m_c8);
      break;
    case 106:
      this.m_tstates += 8;
      bit(5, this.m_d8);
      break;
    case 107:
      this.m_tstates += 8;
      bit(5, this.m_e8);
      break;
    case 108:
      this.m_tstates += 8;
      bit(5, this.m_h8);
      break;
    case 109:
      this.m_tstates += 8;
      bit(5, this.m_l8);
      break;
    case 110:
      this.m_tstates += 12;
      bit_hl(5, this.m_memory.read8(hl16()));
      break;
    case 111:
      this.m_tstates += 8;
      bit(5, this.m_a8);
      break;
    case 112:
      this.m_tstates += 8;
      bit(6, this.m_b8);
      break;
    case 113:
      this.m_tstates += 8;
      bit(6, this.m_c8);
      break;
    case 114:
      this.m_tstates += 8;
      bit(6, this.m_d8);
      break;
    case 115:
      this.m_tstates += 8;
      bit(6, this.m_e8);
      break;
    case 116:
      this.m_tstates += 8;
      bit(6, this.m_h8);
      break;
    case 117:
      this.m_tstates += 8;
      bit(6, this.m_l8);
      break;
    case 118:
      this.m_tstates += 12;
      bit_hl(6, this.m_memory.read8(hl16()));
      break;
    case 119:
      this.m_tstates += 8;
      bit(6, this.m_a8);
      break;
    case 120:
      this.m_tstates += 8;
      bit(7, this.m_b8);
      break;
    case 121:
      this.m_tstates += 8;
      bit(7, this.m_c8);
      break;
    case 122:
      this.m_tstates += 8;
      bit(7, this.m_d8);
      break;
    case 123:
      this.m_tstates += 8;
      bit(7, this.m_e8);
      break;
    case 124:
      this.m_tstates += 8;
      bit(7, this.m_h8);
      break;
    case 125:
      this.m_tstates += 8;
      bit(7, this.m_l8);
      break;
    case 126:
      this.m_tstates += 12;
      bit_hl(7, this.m_memory.read8(hl16()));
      break;
    case 127:
      this.m_tstates += 8;
      bit(7, this.m_a8);
      break;
    case 128:
      this.m_tstates += 8;
      this.m_b8 &= 254;
      break;
    case 129:
      this.m_tstates += 8;
      this.m_c8 &= 254;
      break;
    case 130:
      this.m_tstates += 8;
      this.m_d8 &= 254;
      break;
    case 131:
      this.m_tstates += 8;
      this.m_e8 &= 254;
      break;
    case 132:
      this.m_tstates += 8;
      this.m_h8 &= 254;
      break;
    case 133:
      this.m_tstates += 8;
      this.m_l8 &= 254;
      break;
    case 134:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xFE);
      break;
    case 135:
      this.m_tstates += 8;
      this.m_a8 &= 254;
      break;
    case 136:
      this.m_tstates += 8;
      this.m_b8 &= 253;
      break;
    case 137:
      this.m_tstates += 8;
      this.m_c8 &= 253;
      break;
    case 138:
      this.m_tstates += 8;
      this.m_d8 &= 253;
      break;
    case 139:
      this.m_tstates += 8;
      this.m_e8 &= 253;
      break;
    case 140:
      this.m_tstates += 8;
      this.m_h8 &= 253;
      break;
    case 141:
      this.m_tstates += 8;
      this.m_l8 &= 253;
      break;
    case 142:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xFD);
      break;
    case 143:
      this.m_tstates += 8;
      this.m_a8 &= 253;
      break;
    case 144:
      this.m_tstates += 8;
      this.m_b8 &= 251;
      break;
    case 145:
      this.m_tstates += 8;
      this.m_c8 &= 251;
      break;
    case 146:
      this.m_tstates += 8;
      this.m_d8 &= 251;
      break;
    case 147:
      this.m_tstates += 8;
      this.m_e8 &= 251;
      break;
    case 148:
      this.m_tstates += 8;
      this.m_h8 &= 251;
      break;
    case 149:
      this.m_tstates += 8;
      this.m_l8 &= 251;
      break;
    case 150:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xFB);
      break;
    case 151:
      this.m_tstates += 8;
      this.m_a8 &= 251;
      break;
    case 152:
      this.m_tstates += 8;
      this.m_b8 &= 247;
      break;
    case 153:
      this.m_tstates += 8;
      this.m_c8 &= 247;
      break;
    case 154:
      this.m_tstates += 8;
      this.m_d8 &= 247;
      break;
    case 155:
      this.m_tstates += 8;
      this.m_e8 &= 247;
      break;
    case 156:
      this.m_tstates += 8;
      this.m_h8 &= 247;
      break;
    case 157:
      this.m_tstates += 8;
      this.m_l8 &= 247;
      break;
    case 158:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xF7);
      break;
    case 159:
      this.m_tstates += 8;
      this.m_a8 &= 247;
      break;
    case 160:
      this.m_tstates += 8;
      this.m_b8 &= 239;
      break;
    case 161:
      this.m_tstates += 8;
      this.m_c8 &= 239;
      break;
    case 162:
      this.m_tstates += 8;
      this.m_d8 &= 239;
      break;
    case 163:
      this.m_tstates += 8;
      this.m_e8 &= 239;
      break;
    case 164:
      this.m_tstates += 8;
      this.m_h8 &= 239;
      break;
    case 165:
      this.m_tstates += 8;
      this.m_l8 &= 239;
      break;
    case 166:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xEF);
      break;
    case 167:
      this.m_tstates += 8;
      this.m_a8 &= 239;
      break;
    case 168:
      this.m_tstates += 8;
      this.m_b8 &= 223;
      break;
    case 169:
      this.m_tstates += 8;
      this.m_c8 &= 223;
      break;
    case 170:
      this.m_tstates += 8;
      this.m_d8 &= 223;
      break;
    case 171:
      this.m_tstates += 8;
      this.m_e8 &= 223;
      break;
    case 172:
      this.m_tstates += 8;
      this.m_h8 &= 223;
      break;
    case 173:
      this.m_tstates += 8;
      this.m_l8 &= 223;
      break;
    case 174:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xDF);
      break;
    case 175:
      this.m_tstates += 8;
      this.m_a8 &= 223;
      break;
    case 176:
      this.m_tstates += 8;
      this.m_b8 &= 191;
      break;
    case 177:
      this.m_tstates += 8;
      this.m_c8 &= 191;
      break;
    case 178:
      this.m_tstates += 8;
      this.m_d8 &= 191;
      break;
    case 179:
      this.m_tstates += 8;
      this.m_e8 &= 191;
      break;
    case 180:
      this.m_tstates += 8;
      this.m_h8 &= 191;
      break;
    case 181:
      this.m_tstates += 8;
      this.m_l8 &= 191;
      break;
    case 182:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0xBF);
      break;
    case 183:
      this.m_tstates += 8;
      this.m_a8 &= 191;
      break;
    case 184:
      this.m_tstates += 8;
      this.m_b8 &= 127;
      break;
    case 185:
      this.m_tstates += 8;
      this.m_c8 &= 127;
      break;
    case 186:
      this.m_tstates += 8;
      this.m_d8 &= 127;
      break;
    case 187:
      this.m_tstates += 8;
      this.m_e8 &= 127;
      break;
    case 188:
      this.m_tstates += 8;
      this.m_h8 &= 127;
      break;
    case 189:
      this.m_tstates += 8;
      this.m_l8 &= 127;
      break;
    case 190:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) & 0x7F);
      break;
    case 191:
      this.m_tstates += 8;
      this.m_a8 &= 127;
      break;
    case 192:
      this.m_tstates += 8;
      this.m_b8 |= 1;
      break;
    case 193:
      this.m_tstates += 8;
      this.m_c8 |= 1;
      break;
    case 194:
      this.m_tstates += 8;
      this.m_d8 |= 1;
      break;
    case 195:
      this.m_tstates += 8;
      this.m_e8 |= 1;
      break;
    case 196:
      this.m_tstates += 8;
      this.m_h8 |= 1;
      break;
    case 197:
      this.m_tstates += 8;
      this.m_l8 |= 1;
      break;
    case 198:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x1);
      break;
    case 199:
      this.m_tstates += 8;
      this.m_a8 |= 1;
      break;
    case 200:
      this.m_tstates += 8;
      this.m_b8 |= 2;
      break;
    case 201:
      this.m_tstates += 8;
      this.m_c8 |= 2;
      break;
    case 202:
      this.m_tstates += 8;
      this.m_d8 |= 2;
      break;
    case 203:
      this.m_tstates += 8;
      this.m_e8 |= 2;
      break;
    case 204:
      this.m_tstates += 8;
      this.m_h8 |= 2;
      break;
    case 205:
      this.m_tstates += 8;
      this.m_l8 |= 2;
      break;
    case 206:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x2);
      break;
    case 207:
      this.m_tstates += 8;
      this.m_a8 |= 2;
      break;
    case 208:
      this.m_tstates += 8;
      this.m_b8 |= 4;
      break;
    case 209:
      this.m_tstates += 8;
      this.m_c8 |= 4;
      break;
    case 210:
      this.m_tstates += 8;
      this.m_d8 |= 4;
      break;
    case 211:
      this.m_tstates += 8;
      this.m_e8 |= 4;
      break;
    case 212:
      this.m_tstates += 8;
      this.m_h8 |= 4;
      break;
    case 213:
      this.m_tstates += 8;
      this.m_l8 |= 4;
      break;
    case 214:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x4);
      break;
    case 215:
      this.m_tstates += 8;
      this.m_a8 |= 4;
      break;
    case 216:
      this.m_tstates += 8;
      this.m_b8 |= 8;
      break;
    case 217:
      this.m_tstates += 8;
      this.m_c8 |= 8;
      break;
    case 218:
      this.m_tstates += 8;
      this.m_d8 |= 8;
      break;
    case 219:
      this.m_tstates += 8;
      this.m_e8 |= 8;
      break;
    case 220:
      this.m_tstates += 8;
      this.m_h8 |= 8;
      break;
    case 221:
      this.m_tstates += 8;
      this.m_l8 |= 8;
      break;
    case 222:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x8);
      break;
    case 223:
      this.m_tstates += 8;
      this.m_a8 |= 8;
      break;
    case 224:
      this.m_tstates += 8;
      this.m_b8 |= 16;
      break;
    case 225:
      this.m_tstates += 8;
      this.m_c8 |= 16;
      break;
    case 226:
      this.m_tstates += 8;
      this.m_d8 |= 16;
      break;
    case 227:
      this.m_tstates += 8;
      this.m_e8 |= 16;
      break;
    case 228:
      this.m_tstates += 8;
      this.m_h8 |= 16;
      break;
    case 229:
      this.m_tstates += 8;
      this.m_l8 |= 16;
      break;
    case 230:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x10);
      break;
    case 231:
      this.m_tstates += 8;
      this.m_a8 |= 16;
      break;
    case 232:
      this.m_tstates += 8;
      this.m_b8 |= 32;
      break;
    case 233:
      this.m_tstates += 8;
      this.m_c8 |= 32;
      break;
    case 234:
      this.m_tstates += 8;
      this.m_d8 |= 32;
      break;
    case 235:
      this.m_tstates += 8;
      this.m_e8 |= 32;
      break;
    case 236:
      this.m_tstates += 8;
      this.m_h8 |= 32;
      break;
    case 237:
      this.m_tstates += 8;
      this.m_l8 |= 32;
      break;
    case 238:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x20);
      break;
    case 239:
      this.m_tstates += 8;
      this.m_a8 |= 32;
      break;
    case 240:
      this.m_tstates += 8;
      this.m_b8 |= 64;
      break;
    case 241:
      this.m_tstates += 8;
      this.m_c8 |= 64;
      break;
    case 242:
      this.m_tstates += 8;
      this.m_d8 |= 64;
      break;
    case 243:
      this.m_tstates += 8;
      this.m_e8 |= 64;
      break;
    case 244:
      this.m_tstates += 8;
      this.m_h8 |= 64;
      break;
    case 245:
      this.m_tstates += 8;
      this.m_l8 |= 64;
      break;
    case 246:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x40);
      break;
    case 247:
      this.m_tstates += 8;
      this.m_a8 |= 64;
      break;
    case 248:
      this.m_tstates += 8;
      this.m_b8 |= 128;
      break;
    case 249:
      this.m_tstates += 8;
      this.m_c8 |= 128;
      break;
    case 250:
      this.m_tstates += 8;
      this.m_d8 |= 128;
      break;
    case 251:
      this.m_tstates += 8;
      this.m_e8 |= 128;
      break;
    case 252:
      this.m_tstates += 8;
      this.m_h8 |= 128;
      break;
    case 253:
      this.m_tstates += 8;
      this.m_l8 |= 128;
      break;
    case 254:
      this.m_tstates += 15;
      this.m_memory.write8(hl16(), this.m_memory.read8(hl16()) | 0x80);
      break;
    case 255:
      this.m_tstates += 8;
      this.m_a8 |= 128;
    }
  }

  public void decodeXX(int paramInt)
  {
    int i = 0;
    int j = 0;
    switch (paramInt)
    {
    case 9:
      this.m_tstates += 15;
      add_xx(bc16());
      break;
    case 25:
      this.m_tstates += 15;
      add_xx(de16());
      break;
    case 33:
      this.m_tstates += 14;
      this.m_xx16 = this.m_memory.read16(this.m_pc16);
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 34:
      this.m_tstates += 20;
      this.m_memory.write16(this.m_memory.read16(this.m_pc16), this.m_xx16);
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 35:
      this.m_tstates += 10;
      inc16xx();
      break;
    case 36:
      this.m_tstates += 8;
      xx16high8(inc8(xx16high8()));
      break;
    case 37:
      this.m_tstates += 8;
      xx16high8(dec8(xx16high8()));
      break;
    case 38:
      this.m_tstates += 11;
      xx16high8(this.m_memory.read8(inc16pc()));
      break;
    case 41:
      this.m_tstates += 15;
      add_xx(this.m_xx16);
      break;
    case 42:
      this.m_tstates += 20;
      this.m_xx16 = this.m_memory.read16(this.m_memory.read16(this.m_pc16));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 43:
      this.m_tstates += 10;
      dec16xx();
      break;
    case 44:
      this.m_tstates += 8;
      xx16low8(inc8(xx16low8()));
      break;
    case 45:
      this.m_tstates += 8;
      xx16low8(dec8(xx16low8()));
      break;
    case 46:
      this.m_tstates += 11;
      xx16low8(this.m_memory.read8(inc16pc()));
      break;
    case 52:
      this.m_tstates += 23;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      j = this.m_memory.read8(i);
      j = inc8(j);
      this.m_memory.write8(i, j);
      break;
    case 53:
      this.m_tstates += 23;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      j = this.m_memory.read8(i);
      j = dec8(j);
      this.m_memory.write8(i, j);
      break;
    case 54:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(this.m_pc16)), this.m_memory.read8(inc16(this.m_pc16)));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 57:
      this.m_tstates += 15;
      add_xx(this.m_sp16);
      break;
    case 68:
      this.m_tstates += 8;
      this.m_b8 = xx16high8();
      break;
    case 69:
      this.m_tstates += 8;
      this.m_b8 = xx16low8();
      break;
    case 70:
      this.m_tstates += 15;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_b8 = this.m_memory.read8(i);
      break;
    case 76:
      this.m_tstates += 8;
      this.m_c8 = xx16high8();
      break;
    case 77:
      this.m_tstates += 8;
      this.m_c8 = xx16low8();
      break;
    case 78:
      this.m_tstates += 15;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_c8 = this.m_memory.read8(i);
      break;
    case 84:
      this.m_tstates += 8;
      this.m_d8 = xx16high8();
      break;
    case 85:
      this.m_tstates += 8;
      this.m_d8 = xx16low8();
      break;
    case 86:
      this.m_tstates += 19;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_d8 = this.m_memory.read8(i);
      break;
    case 92:
      this.m_tstates += 8;
      this.m_e8 = xx16high8();
      break;
    case 93:
      this.m_tstates += 8;
      this.m_e8 = xx16low8();
      break;
    case 94:
      this.m_tstates += 19;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_e8 = this.m_memory.read8(i);
      break;
    case 96:
      this.m_tstates += 8;
      xx16high8(this.m_b8);
      break;
    case 97:
      this.m_tstates += 8;
      xx16high8(this.m_c8);
      break;
    case 98:
      this.m_tstates += 8;
      xx16high8(this.m_d8);
      break;
    case 99:
      this.m_tstates += 8;
      xx16high8(this.m_e8);
      break;
    case 100:
      this.m_tstates += 8;
      break;
    case 101:
      this.m_tstates += 8;
      xx16high8(xx16low8());
      break;
    case 102:
      this.m_tstates += 19;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_h8 = this.m_memory.read8(i);
      break;
    case 103:
      this.m_tstates += 8;
      xx16high8(this.m_a8);
      break;
    case 104:
      this.m_tstates += 8;
      xx16low8(this.m_b8);
      break;
    case 105:
      this.m_tstates += 8;
      xx16low8(this.m_c8);
      break;
    case 106:
      this.m_tstates += 8;
      xx16low8(this.m_d8);
      break;
    case 107:
      this.m_tstates += 8;
      xx16low8(this.m_e8);
      break;
    case 108:
      this.m_tstates += 8;
      xx16low8(xx16high8());
      break;
    case 109:
      this.m_tstates += 8;
      break;
    case 110:
      this.m_tstates += 19;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_l8 = this.m_memory.read8(i);
      break;
    case 111:
      this.m_tstates += 8;
      xx16low8(this.m_a8);
      break;
    case 112:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_b8);
      break;
    case 113:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_c8);
      break;
    case 114:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_d8);
      break;
    case 115:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_e8);
      break;
    case 116:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_h8);
      break;
    case 117:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_l8);
      break;
    case 119:
      this.m_tstates += 19;
      this.m_memory.write8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())), this.m_a8);
      break;
    case 124:
      this.m_tstates += 8;
      this.m_a8 = xx16high8();
      break;
    case 125:
      this.m_tstates += 8;
      this.m_a8 = xx16low8();
      break;
    case 126:
      this.m_tstates += 19;
      i = add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc()));
      this.m_x8 = (i >> 8);
      this.m_a8 = this.m_memory.read8(i);
      break;
    case 132:
      this.m_tstates += 8;
      add_a(xx16high8());
      break;
    case 133:
      this.m_tstates += 8;
      add_a(xx16low8());
      break;
    case 134:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      add_a(j);
      break;
    case 140:
      this.m_tstates += 8;
      adc_a(xx16high8());
      break;
    case 141:
      this.m_tstates += 8;
      adc_a(xx16low8());
      break;
    case 142:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      adc_a(j);
      break;
    case 148:
      this.m_tstates += 8;
      sub_a(xx16high8());
      break;
    case 149:
      this.m_tstates += 8;
      sub_a(xx16low8());
      break;
    case 150:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      sub_a(j);
      break;
    case 156:
      this.m_tstates += 8;
      sbc_a(xx16high8());
      break;
    case 157:
      this.m_tstates += 8;
      sbc_a(xx16low8());
      break;
    case 158:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      sbc_a(j);
      break;
    case 164:
      this.m_tstates += 8;
      and_a(xx16high8());
      break;
    case 165:
      this.m_tstates += 8;
      and_a(xx16low8());
      break;
    case 166:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      and_a(j);
      break;
    case 172:
      this.m_tstates += 8;
      xor_a(xx16high8());
      break;
    case 173:
      this.m_tstates += 8;
      xor_a(xx16low8());
      break;
    case 174:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      xor_a(j);
      break;
    case 180:
      this.m_tstates += 8;
      or_a(xx16high8());
      break;
    case 181:
      this.m_tstates += 8;
      or_a(xx16low8());
      break;
    case 182:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      or_a(j);
      break;
    case 188:
      this.m_tstates += 8;
      cmp_a(xx16high8());
      break;
    case 189:
      this.m_tstates += 8;
      cmp_a(xx16low8());
      break;
    case 190:
      this.m_tstates += 19;
      j = this.m_memory.read8(add16(this.m_xx16, (byte)this.m_memory.read8(inc16pc())));
      cmp_a(j);
      break;
    case 203:
      int k = (byte)this.m_memory.read8(inc16pc());
      this.m_xx16 = add16(this.m_xx16, k);
      switch (this.m_memory.read8(inc16pc()))
      {
      case 0:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = rlc8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 1:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = rlc8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 2:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = rlc8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 3:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = rlc8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 4:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = rlc8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 5:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = rlc8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 6:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = rlc8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 7:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = rlc8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 8:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = rrc8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 9:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = rrc8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 10:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = rrc8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 11:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = rrc8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 12:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = rrc8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 13:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = rrc8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 14:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = rrc8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 15:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = rrc8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 16:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = rl8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 17:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = rl8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 18:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = rl8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 19:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = rl8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 20:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = rl8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 21:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = rl8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 22:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = rl8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 23:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = rl8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 24:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = rr8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 25:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = rr8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 26:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = rr8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 27:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = rr8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 28:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = rr8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 29:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = rr8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 30:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = rr8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 31:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = rr8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 32:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = sla8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 33:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = sla8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 34:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = sla8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 35:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = sla8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 36:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = sla8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 37:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = sla8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 38:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = sla8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 39:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = sla8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 40:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = sra8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 41:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = sra8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 42:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = sra8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 43:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = sra8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 44:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = sra8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 45:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = sra8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 46:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = sra8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 47:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = sra8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 48:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = sli8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 49:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = sli8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 50:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = sli8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 51:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = sli8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 52:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = sli8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 53:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = sli8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 54:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = sli8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 55:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = sli8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 56:
        this.m_tstates += 23;
        this.m_b8 = this.m_memory.read8(this.m_xx16);
        this.m_b8 = srl8(this.m_b8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 57:
        this.m_tstates += 23;
        this.m_c8 = this.m_memory.read8(this.m_xx16);
        this.m_c8 = srl8(this.m_c8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 58:
        this.m_tstates += 23;
        this.m_d8 = this.m_memory.read8(this.m_xx16);
        this.m_d8 = srl8(this.m_d8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 59:
        this.m_tstates += 23;
        this.m_e8 = this.m_memory.read8(this.m_xx16);
        this.m_e8 = srl8(this.m_e8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 60:
        this.m_tstates += 23;
        this.m_h8 = this.m_memory.read8(this.m_xx16);
        this.m_h8 = srl8(this.m_h8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 61:
        this.m_tstates += 23;
        this.m_l8 = this.m_memory.read8(this.m_xx16);
        this.m_l8 = srl8(this.m_l8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 62:
        this.m_tstates += 23;
        j = this.m_memory.read8(this.m_xx16);
        j = srl8(j);
        this.m_memory.write8(this.m_xx16, j);
        break;
      case 63:
        this.m_tstates += 23;
        this.m_a8 = this.m_memory.read8(this.m_xx16);
        this.m_a8 = srl8(this.m_a8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
        this.m_tstates += 20;
        bit_xx(0, this.m_memory.read8(this.m_xx16));
        break;
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
        this.m_tstates += 20;
        bit_xx(1, this.m_memory.read8(this.m_xx16));
        break;
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
        this.m_tstates += 20;
        bit_xx(2, this.m_memory.read8(this.m_xx16));
        break;
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 94:
      case 95:
        this.m_tstates += 20;
        bit_xx(3, this.m_memory.read8(this.m_xx16));
        break;
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
        this.m_tstates += 20;
        bit_xx(4, this.m_memory.read8(this.m_xx16));
        break;
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
        this.m_tstates += 20;
        bit_xx(5, this.m_memory.read8(this.m_xx16));
        break;
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
        this.m_tstates += 20;
        bit_xx(6, this.m_memory.read8(this.m_xx16));
        break;
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 127:
        this.m_tstates += 20;
        bit_xx(7, this.m_memory.read8(this.m_xx16));
        break;
      case 128:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 129:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 130:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 131:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 132:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 133:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 134:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xFE);
        break;
      case 135:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xFE);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 136:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 137:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 138:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 139:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 140:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 141:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 142:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xFD);
        break;
      case 143:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xFD);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 144:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 145:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 146:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 147:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 148:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 149:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 150:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xFB);
        break;
      case 151:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xFB);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 152:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 153:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 154:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 155:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 156:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 157:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 158:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xF7);
        break;
      case 159:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xF7);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 160:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 161:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 162:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 163:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 164:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 165:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 166:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xEF);
        break;
      case 167:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xEF);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 168:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 169:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 170:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 171:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 172:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 173:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 174:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xDF);
        break;
      case 175:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xDF);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 176:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 177:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 178:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 179:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 180:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 181:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 182:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0xBF);
        break;
      case 183:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0xBF);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 184:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 185:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 186:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 187:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 188:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 189:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 190:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) & 0x7F);
        break;
      case 191:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) & 0x7F);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 192:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 193:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 194:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 195:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 196:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 197:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 198:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x1);
        break;
      case 199:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x1);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 200:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 201:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 202:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 203:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 204:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 205:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 206:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x2);
        break;
      case 207:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x2);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 208:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 209:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 210:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 211:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 212:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 213:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 214:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x4);
        break;
      case 215:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x4);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 216:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 217:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 218:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 219:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 220:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 221:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 222:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x8);
        break;
      case 223:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x8);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 224:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 225:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 226:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 227:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 228:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 229:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 230:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x10);
        break;
      case 231:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x10);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 232:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 233:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 234:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 235:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 236:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 237:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 238:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x20);
        break;
      case 239:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x20);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 240:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 241:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 242:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 243:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 244:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 245:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 246:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x40);
        break;
      case 247:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x40);
        this.m_memory.write8(this.m_xx16, this.m_a8);
        break;
      case 248:
        this.m_tstates += 23;
        this.m_b8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_b8);
        break;
      case 249:
        this.m_tstates += 23;
        this.m_c8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_c8);
        break;
      case 250:
        this.m_tstates += 23;
        this.m_d8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_d8);
        break;
      case 251:
        this.m_tstates += 23;
        this.m_e8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_e8);
        break;
      case 252:
        this.m_tstates += 23;
        this.m_h8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_h8);
        break;
      case 253:
        this.m_tstates += 23;
        this.m_l8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_l8);
        break;
      case 254:
        this.m_tstates += 23;
        this.m_memory.write8(this.m_xx16, this.m_memory.read8(this.m_xx16) | 0x80);
        break;
      case 255:
        this.m_tstates += 23;
        this.m_a8 = (this.m_memory.read8(this.m_xx16) | 0x80);
        this.m_memory.write8(this.m_xx16, this.m_a8);
      }
      this.m_xx16 = sub16(this.m_xx16, k);
      break;
    case 225:
      this.m_tstates += 14;
      this.m_xx16 = pop16();
      break;
    case 227:
      this.m_tstates += 23;
      i = this.m_memory.read16(this.m_sp16);
      this.m_memory.write16(this.m_sp16, this.m_xx16);
      this.m_xx16 = i;
      break;
    case 229:
      this.m_tstates += 15;
      push(this.m_xx16);
      break;
    case 233:
      this.m_tstates += 8;
      this.m_pc16 = this.m_xx16;
      break;
    case 249:
      this.m_tstates += 10;
      this.m_sp16 = this.m_xx16;
      break;
    case 221:
    case 253:
      this.m_tstates += 4;
      dec16pc();
      break;
    case 235:
    case 237:
      this.m_tstates += 8;
      break;
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
    case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 26:
    case 27:
    case 28:
    case 29:
    case 30:
    case 31:
    case 32:
    case 39:
    case 40:
    case 47:
    case 48:
    case 49:
    case 50:
    case 51:
    case 55:
    case 56:
    case 58:
    case 59:
    case 60:
    case 61:
    case 62:
    case 63:
    case 64:
    case 65:
    case 66:
    case 67:
    case 71:
    case 72:
    case 73:
    case 74:
    case 75:
    case 79:
    case 80:
    case 81:
    case 82:
    case 83:
    case 87:
    case 88:
    case 89:
    case 90:
    case 91:
    case 95:
    case 118:
    case 120:
    case 121:
    case 122:
    case 123:
    case 127:
    case 128:
    case 129:
    case 130:
    case 131:
    case 135:
    case 136:
    case 137:
    case 138:
    case 139:
    case 143:
    case 144:
    case 145:
    case 146:
    case 147:
    case 151:
    case 152:
    case 153:
    case 154:
    case 155:
    case 159:
    case 160:
    case 161:
    case 162:
    case 163:
    case 167:
    case 168:
    case 169:
    case 170:
    case 171:
    case 175:
    case 176:
    case 177:
    case 178:
    case 179:
    case 183:
    case 184:
    case 185:
    case 186:
    case 187:
    case 191:
    case 192:
    case 193:
    case 194:
    case 195:
    case 196:
    case 197:
    case 198:
    case 199:
    case 200:
    case 201:
    case 202:
    case 204:
    case 205:
    case 206:
    case 207:
    case 208:
    case 209:
    case 210:
    case 211:
    case 212:
    case 213:
    case 214:
    case 215:
    case 216:
    case 217:
    case 218:
    case 219:
    case 220:
    case 222:
    case 223:
    case 224:
    case 226:
    case 228:
    case 230:
    case 231:
    case 232:
    case 234:
    case 236:
    case 238:
    case 239:
    case 240:
    case 241:
    case 242:
    case 243:
    case 244:
    case 245:
    case 246:
    case 247:
    case 248:
    case 250:
    case 251:
    case 252:
    default:
      this.m_tstates += 4;
      dec16pc();
      this.m_logger.log(0, "Unimplemented instruction: " + this.m_memory.read8(dec16(this.m_pc16)) + " " + this.m_memory.read8(this.m_pc16) + " at " + dec16(this.m_pc16));
    }
  }

  private void decodeED(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    case 64:
      this.m_tstates += 12;
      this.m_b8 = in8(bc16());
      break;
    case 65:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_b8);
      break;
    case 66:
      this.m_tstates += 15;
      sbc_hl(bc16());
      break;
    case 67:
      this.m_tstates += 20;
      this.m_memory.write16(this.m_memory.read16(this.m_pc16), bc16());
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 68:
    case 76:
    case 84:
    case 92:
    case 100:
    case 108:
    case 116:
    case 124:
      this.m_tstates += 8;
      i = this.m_a8;
      this.m_a8 = 0;
      sub_a(i);
      break;
    case 69:
    case 85:
    case 93:
    case 101:
    case 109:
    case 117:
    case 125:
      this.m_tstates += 14;
      this.m_pc16 = pop16();
      this.m_iff1a = this.m_iff1b;
      break;
    case 70:
    case 78:
    case 102:
    case 110:
      this.m_tstates += 8;
      this.m_im2 = 0;
      break;
    case 71:
      this.m_tstates += 9;
      this.m_i8 = this.m_a8;
      break;
    case 72:
      this.m_tstates += 12;
      this.m_c8 = in8(bc16());
      break;
    case 73:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_c8);
      break;
    case 74:
      this.m_tstates += 15;
      adc_hl(bc16());
      break;
    case 75:
      this.m_tstates += 20;
      bc16(this.m_memory.read16(this.m_memory.read16(this.m_pc16)));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 77:
      this.m_tstates += 14;
      this.m_pc16 = pop16();
      break;
    case 79:
      this.m_tstates += 9;
      this.m_r8 = this.m_a8;
      break;
    case 80:
      this.m_tstates += 12;
      this.m_d8 = in8(bc16());
      break;
    case 81:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_d8);
      break;
    case 82:
      this.m_tstates += 15;
      sbc_hl(de16());
      break;
    case 83:
      this.m_tstates += 20;
      this.m_memory.write16(this.m_memory.read16(this.m_pc16), de16());
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 86:
    case 118:
      this.m_tstates += 8;
      this.m_im2 = 1;
      break;
    case 87:
      this.m_tstates += 9;
      ld_a_special(this.m_i8);
      break;
    case 88:
      this.m_tstates += 12;
      this.m_e8 = in8(bc16());
      break;
    case 89:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_e8);
      break;
    case 90:
      this.m_tstates += 15;
      adc_hl(de16());
      break;
    case 91:
      this.m_tstates += 20;
      de16(this.m_memory.read16(this.m_memory.read16(this.m_pc16)));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 94:
    case 126:
      this.m_tstates += 8;
      this.m_im2 = 2;
      break;
    case 95:
      this.m_tstates += 9;
      ld_a_special(this.m_r8);
      break;
    case 96:
      this.m_tstates += 12;
      this.m_h8 = in8(bc16());
      break;
    case 97:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_h8);
      break;
    case 98:
      this.m_tstates += 15;
      sbc_hl(hl16());
      break;
    case 99:
      this.m_tstates += 20;
      this.m_memory.write16(this.m_memory.read16(this.m_pc16), hl16());
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 103:
      this.m_tstates += 18;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(hl16(), i >> 4 | this.m_a8 << 4);
      this.m_a8 = (this.m_a8 & 0xF0 | i & 0xF);
      this.m_signF = ((this.m_a8 & 0x80) != 0);
      this.m_zeroF = (this.m_a8 == 0);
      this.m_halfcarryF = false;
      this.m_parityoverflowF = m_parityTable[this.m_a8];
      this.m_addsubtractF = false;
      this.m_3F = ((this.m_a8 & 0x8) != 0);
      this.m_5F = ((this.m_a8 & 0x20) != 0);
      break;
    case 104:
      this.m_tstates += 12;
      this.m_l8 = in8(bc16());
      break;
    case 105:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_l8);
      break;
    case 106:
      this.m_tstates += 15;
      adc_hl(hl16());
      break;
    case 107:
      this.m_tstates += 20;
      hl16(this.m_memory.read16(this.m_memory.read16(this.m_pc16)));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 111:
      this.m_tstates += 18;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(hl16(), (i << 4 | this.m_a8 & 0xF) & 0xFF);
      this.m_a8 = (this.m_a8 & 0xF0 | i >> 4);
      this.m_signF = ((this.m_a8 & 0x80) != 0);
      this.m_zeroF = (this.m_a8 == 0);
      this.m_halfcarryF = false;
      this.m_parityoverflowF = m_parityTable[this.m_a8];
      this.m_addsubtractF = false;
      this.m_3F = ((this.m_a8 & 0x8) != 0);
      this.m_5F = ((this.m_a8 & 0x20) != 0);
      break;
    case 112:
      this.m_tstates += 12;
      in8(bc16());
      break;
    case 113:
      this.m_tstates += 12;
      this.m_io.out(bc16(), 0);
      break;
    case 114:
      this.m_tstates += 15;
      sbc_hl(this.m_sp16);
      break;
    case 115:
      this.m_tstates += 20;
      this.m_memory.write16(this.m_memory.read16(this.m_pc16), this.m_sp16);
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 119:
    case 127:
      this.m_tstates += 8;
      break;
    case 120:
      this.m_tstates += 12;
      this.m_a8 = in8(bc16());
      break;
    case 121:
      this.m_tstates += 12;
      this.m_io.out(bc16(), this.m_a8);
      break;
    case 122:
      this.m_tstates += 15;
      adc_hl(this.m_sp16);
      break;
    case 123:
      this.m_tstates += 20;
      this.m_sp16 = this.m_memory.read16(this.m_memory.read16(this.m_pc16));
      this.m_pc16 = incinc16(this.m_pc16);
      break;
    case 160:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(de16(), i);
      inc16de();
      inc16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      this.m_halfcarryF = false;
      this.m_addsubtractF = false;
      i += this.m_a8;
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 161:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      cmp_a_special(i);
      inc16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      i = this.m_a8 - i - (this.m_halfcarryF ? 1 : 0);
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 162:
      this.m_tstates += 16;
      this.m_memory.write8(hl16(), this.m_io.in8(bc16()));
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      inc16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      break;
    case 163:
      this.m_tstates += 16;
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      this.m_io.out(bc16(), this.m_memory.read8(hl16()));
      inc16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      break;
    case 168:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(de16(), i);
      dec16de();
      dec16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      this.m_halfcarryF = false;
      this.m_addsubtractF = false;
      i += this.m_a8;
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 169:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      cmp_a_special(i);
      dec16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      i = this.m_a8 - i - (this.m_halfcarryF ? 1 : 0);
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 170:
      this.m_tstates += 16;
      this.m_memory.write8(hl16(), this.m_io.in8(bc16()));
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      dec16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      break;
    case 171:
      this.m_tstates += 16;
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      this.m_io.out(bc16(), this.m_memory.read8(hl16()));
      dec16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      break;
    case 176:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(de16(), i);
      inc16hl();
      inc16de();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      this.m_halfcarryF = false;
      this.m_addsubtractF = false;
      if (this.m_parityoverflowF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      i += this.m_a8;
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 177:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      cmp_a_special(i);
      inc16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      if ((this.m_parityoverflowF) && (!this.m_zeroF))
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      i = this.m_a8 - i - (this.m_halfcarryF ? 1 : 0);
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 178:
      this.m_tstates += 16;
      this.m_memory.write8(hl16(), this.m_io.in8(bc16()));
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      inc16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      if (!this.m_zeroF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      break;
    case 179:
      this.m_tstates += 16;
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      this.m_io.out(bc16(), this.m_memory.read8(hl16()));
      inc16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      if (!this.m_zeroF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      break;
    case 184:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      this.m_memory.write8(de16(), i);
      dec16hl();
      dec16de();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      this.m_halfcarryF = false;
      this.m_addsubtractF = false;
      if (this.m_parityoverflowF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      i += this.m_a8;
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 185:
      this.m_tstates += 16;
      i = this.m_memory.read8(hl16());
      cmp_a_special(i);
      dec16hl();
      dec16bc();
      this.m_parityoverflowF = (bc16() != 0);
      if ((this.m_parityoverflowF) && (!this.m_zeroF))
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      i = this.m_a8 - i - (this.m_halfcarryF ? 1 : 0);
      this.m_3F = ((i & 0x8) != 0);
      this.m_5F = ((i & 0x1) != 0);
      break;
    case 186:
      this.m_tstates += 16;
      this.m_memory.write8(hl16(), this.m_io.in8(bc16()));
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      dec16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      if (!this.m_zeroF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      break;
    case 187:
      this.m_tstates += 16;
      this.m_b8 = (this.m_b8 - 1 & 0xFF);
      this.m_io.out(bc16(), this.m_memory.read8(hl16()));
      dec16hl();
      this.m_zeroF = (this.m_b8 == 0);
      this.m_addsubtractF = true;
      if (!this.m_zeroF)
      {
        this.m_tstates += 5;
        this.m_pc16 = decdec16(this.m_pc16);
      }
      break;
    case 251:
      this.m_tstates += 8;
      break;
    case 252:
      this.m_tstates += 8;
      break;
    case 253:
      this.m_tstates += 8;
      break;
    case 128:
    case 129:
    case 130:
    case 131:
    case 132:
    case 133:
    case 134:
    case 135:
    case 136:
    case 137:
    case 138:
    case 139:
    case 140:
    case 141:
    case 142:
    case 143:
    case 144:
    case 145:
    case 146:
    case 147:
    case 148:
    case 149:
    case 150:
    case 151:
    case 152:
    case 153:
    case 154:
    case 155:
    case 156:
    case 157:
    case 158:
    case 159:
    case 164:
    case 165:
    case 166:
    case 167:
    case 172:
    case 173:
    case 174:
    case 175:
    case 180:
    case 181:
    case 182:
    case 183:
    case 188:
    case 189:
    case 190:
    case 191:
    case 192:
    case 193:
    case 194:
    case 195:
    case 196:
    case 197:
    case 198:
    case 199:
    case 200:
    case 201:
    case 202:
    case 203:
    case 204:
    case 205:
    case 206:
    case 207:
    case 208:
    case 209:
    case 210:
    case 211:
    case 212:
    case 213:
    case 214:
    case 215:
    case 216:
    case 217:
    case 218:
    case 219:
    case 220:
    case 221:
    case 222:
    case 223:
    case 224:
    case 225:
    case 226:
    case 227:
    case 228:
    case 229:
    case 230:
    case 231:
    case 232:
    case 233:
    case 234:
    case 235:
    case 236:
    case 237:
    case 238:
    case 239:
    case 240:
    case 241:
    case 242:
    case 243:
    case 244:
    case 245:
    case 246:
    case 247:
    case 248:
    case 249:
    case 250:
    default:
      this.m_tstates += 8;
      this.m_logger.log(0, "Unimplemented instruction: " + this.m_memory.read8(decdec16(this.m_pc16)) + " " + this.m_memory.read8(dec16(this.m_pc16)) + " at " + decdec16(this.m_pc16));
    }
  }

  public String toString()
  {
    storeFlags();
    return "A=" + this.m_a8 + ",F=" + this.m_f8 + ",B=" + this.m_b8 + ",C=" + this.m_c8 + ",D=" + this.m_d8 + ",E=" + this.m_e8 + ",H=" + this.m_h8 + ",L=" + this.m_l8 + ",AF1=" + this.m_af16alt + ",BC1=" + this.m_bc16alt + ",DE1=" + this.m_de16alt + ",HL1=" + this.m_hl16alt + ",IX=" + this.m_ix16 + ",IY=" + this.m_iy16 + ",SP=" + this.m_sp16 + ",PC=" + this.m_pc16 + ",R=" + this.m_r8 + ",I=" + this.m_i8 + ",IM=" + this.m_im2 + ",IFF1=" + this.m_iff1a + ",IFF2=" + this.m_iff1b + ",OP=" + this.m_memory.read8(this.m_pc16);
  }

  public void load(BaseLoader paramBaseLoader)
  {
    af16(paramBaseLoader.getAF16());
    bc16(paramBaseLoader.getBC16());
    de16(paramBaseLoader.getDE16());
    hl16(paramBaseLoader.getHL16());
    this.m_af16alt = paramBaseLoader.getAF16ALT();
    this.m_bc16alt = paramBaseLoader.getBC16ALT();
    this.m_de16alt = paramBaseLoader.getDE16ALT();
    this.m_hl16alt = paramBaseLoader.getHL16ALT();
    this.m_ix16 = paramBaseLoader.getIX16();
    this.m_iy16 = paramBaseLoader.getIY16();
    this.m_sp16 = paramBaseLoader.getSP16();
    this.m_pc16 = paramBaseLoader.getPC16();
    this.m_r8 = paramBaseLoader.getR8();
    this.m_i8 = paramBaseLoader.getI8();
    this.m_im2 = paramBaseLoader.getIM2();
    this.m_iff1a = paramBaseLoader.getIFF1a();
    this.m_iff1b = paramBaseLoader.getIFF1b();
    retrieveFlags();
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.Z80
 * JD-Core Version:    0.6.2
 */