package org.razvan.jzx;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class Z80Loader extends BaseLoader
{
  private static final int EOF = -1;
  private static final int VERSION_1 = 0;
  private static final int VERSION_2 = 23;
  private static final int VERSION_3 = 54;
  private static final int VERSION_3x = 58;
  private int m_version = 0;
  private boolean m_compressed;

  public Z80Loader(ILogger paramILogger, URL paramURL)
  {
    super(paramILogger, paramURL);
  }

  public void load(String paramString)
    throws IOException
  {
    URL localURL = new URL(this.m_url, paramString);
    URLConnection localURLConnection = localURL.openConnection();
    InputStream localInputStream = localURLConnection.getInputStream();
    loadHeader(localInputStream);
    loadBody(localInputStream);
    localInputStream.close();
  }

  protected void loadHeader(InputStream paramInputStream)
    throws IOException
  {
    int i = (byte)paramInputStream.read();
    int j = (byte)paramInputStream.read();
    this.m_af16 = ((i & 0xFF) << 8 | j & 0xFF);
    int k = (byte)paramInputStream.read();
    int m = (byte)paramInputStream.read();
    this.m_bc16 = ((m & 0xFF) << 8 | k & 0xFF);
    int n = (byte)paramInputStream.read();
    int i1 = (byte)paramInputStream.read();
    this.m_hl16 = ((i1 & 0xFF) << 8 | n & 0xFF);
    int i2 = (byte)paramInputStream.read();
    int i3 = (byte)paramInputStream.read();
    this.m_pc16 = ((i3 & 0xFF) << 8 | i2 & 0xFF);
    int i4 = (byte)paramInputStream.read();
    int i5 = (byte)paramInputStream.read();
    this.m_sp16 = ((i5 & 0xFF) << 8 | i4 & 0xFF);
    this.m_i8 = (paramInputStream.read() & 0xFF);
    this.m_r8 = (paramInputStream.read() & 0xFF);
    int i6 = (byte)paramInputStream.read();
    if (i6 == -1)
      i6 = 1;
    this.m_r8 |= (i6 & 0x1) << 7;
    this.m_border = ((i6 & 0xE) >> 1);
    this.m_compressed = ((i6 & 0x20) != 0);
    int i7 = (byte)paramInputStream.read();
    int i8 = (byte)paramInputStream.read();
    this.m_de16 = ((i8 & 0xFF) << 8 | i7 & 0xFF);
    int i9 = (byte)paramInputStream.read();
    int i10 = (byte)paramInputStream.read();
    this.m_bc16alt = ((i10 & 0xFF) << 8 | i9 & 0xFF);
    int i11 = (byte)paramInputStream.read();
    int i12 = (byte)paramInputStream.read();
    this.m_de16alt = ((i12 & 0xFF) << 8 | i11 & 0xFF);
    int i13 = (byte)paramInputStream.read();
    int i14 = (byte)paramInputStream.read();
    this.m_hl16alt = ((i14 & 0xFF) << 8 | i13 & 0xFF);
    int i15 = (byte)paramInputStream.read();
    int i16 = (byte)paramInputStream.read();
    this.m_af16alt = ((i15 & 0xFF) << 8 | i16 & 0xFF);
    int i17 = (byte)paramInputStream.read();
    int i18 = (byte)paramInputStream.read();
    this.m_iy16 = ((i18 & 0xFF) << 8 | i17 & 0xFF);
    int i19 = (byte)paramInputStream.read();
    int i20 = (byte)paramInputStream.read();
    this.m_ix16 = ((i20 & 0xFF) << 8 | i19 & 0xFF);
    this.m_iff1a = ((paramInputStream.read() & 0xFF) != 0 ? 1 : 0);
    this.m_iff1b = ((paramInputStream.read() & 0xFF) != 0 ? 1 : 0);
    int i21 = (byte)paramInputStream.read();
    this.m_im2 = (i21 & 0x3);
    this.m_issue = ((i21 & 0x4) != 0 ? 2 : 3);
    if (this.m_pc16 == 0)
    {
      int i22 = (byte)paramInputStream.read();
      int i23 = (byte)paramInputStream.read();
      this.m_version = ((i23 & 0xFF) << 8 | i22 & 0xFF);
      if ((this.m_version != 23) && (this.m_version != 54) && (this.m_version != 58))
        throw new IOException("Unknown snapshot version: " + this.m_version);
      int i24;
      int i25;
      int i26;
      int i27;
      if (this.m_version >= 23)
      {
        i2 = (byte)paramInputStream.read();
        i3 = (byte)paramInputStream.read();
        this.m_pc16 = ((i3 & 0xFF) << 8 | i2 & 0xFF);
        this.m_mode = (paramInputStream.read() & 0xFF);
        this.m_last0x7ffd = (paramInputStream.read() & 0xFF);
        i24 = (byte)paramInputStream.read();
        i25 = (byte)paramInputStream.read();
        this.m_last0xfffd = (paramInputStream.read() & 0xFF);
        for (i26 = 0; i26 < 16; i26++)
          i27 = (byte)paramInputStream.read();
      }
      if (this.m_version >= 54)
      {
        for (i24 = 0; i24 < 3; i24++)
          i25 = (byte)paramInputStream.read();
        i24 = (byte)paramInputStream.read();
        i25 = (byte)paramInputStream.read();
        i26 = (byte)paramInputStream.read();
        i27 = (byte)paramInputStream.read();
        int i28 = (byte)paramInputStream.read();
        int i30;
        for (int i29 = 0; i29 < 10; i29++)
          i30 = (byte)paramInputStream.read();
        for (i29 = 0; i29 < 10; i29++)
          i30 = (byte)paramInputStream.read();
        if (this.m_version == 54)
        {
          i29 = (byte)paramInputStream.read();
          i30 = (byte)paramInputStream.read();
          int i31 = (byte)paramInputStream.read();
        }
        else
        {
          for (i29 = 0; i29 < 3; i29++)
            i30 = (byte)paramInputStream.read();
        }
      }
      if (this.m_version >= 58)
        for (i24 = 3; i24 < 14; i24++)
          i25 = (byte)paramInputStream.read();
    }
  }

  protected void loadBody(InputStream paramInputStream)
    throws IOException
  {
    int i;
    int j;
    int k;
    int m;
    int n;
    if (this.m_version == 0)
    {
      if (this.m_compressed)
      {
        i = 16384;
        j = 0;
        k = 0;
        m = 0;
        while (true)
        {
          if (m != 0)
          {
            m = 0;
          }
          else
          {
            j = paramInputStream.read();
            if (j == -1)
              break;
            k = (byte)j;
          }
          if (k != -19)
          {
            this.m_memory.write8(i++ & 0xFFFF, k & 0xFF);
          }
          else
          {
            j = paramInputStream.read();
            if (j == -1)
              break;
            k = (byte)j;
            if (k != -19)
            {
              this.m_memory.write8(i++ & 0xFFFF, 237);
              m = 1;
            }
            else
            {
              n = paramInputStream.read();
              if (n == -1)
                break;
              n &= 255;
              j = paramInputStream.read();
              if (j == -1)
                break;
              k = (byte)j;
              while (n-- != 0)
                this.m_memory.write8(i++ & 0xFFFF, k & 0xFF);
            }
          }
        }
        if (i < 65535)
          throw new IOException("Premature EOF on snapshot");
      }
      else
      {
        for (i = 16384; i < 65536; i++)
        {
          j = paramInputStream.read();
          if (j == -1)
            throw new IOException("Premature EOF on snapshot");
          this.m_memory.write8(i, j & 0xFF);
        }
      }
    }
    else
    {
      int i1;
      if ((this.m_version == 58) || (this.m_version == 54))
      {
        i = 3;
        j = 1;
        k = 3;
        m = 6;
        n = 5;
        i1 = 6;
      }
      else if (this.m_version == 23)
      {
        i = 2;
        j = 1;
        k = -1;
        m = 4;
        n = 4;
        i1 = -1;
      }
      else
      {
        throw new IOException("Unknown snapshot version: " + this.m_version);
      }
      int i2;
      if (this.m_mode <= i)
      {
        if (this.m_mode == 2)
        {
          this.m_logger.log(1, "SamRam not supported; defaulting to 48k");
          this.m_mode = 0;
          for (i2 = 0; i2 < 5; i2++)
            loadPage(paramInputStream, i2, (i2 == 2) || (i2 == 3));
        }
        else
        {
          if (this.m_mode == j)
            this.m_logger.log(1, "IF1 not supported; defaulting to 48k");
          if (this.m_mode == k)
            this.m_logger.log(1, "MGT not supported; defaulting to 48k");
          this.m_mode = 0;
          for (i2 = 0; i2 < 3; i2++)
            loadPage(paramInputStream, i2, false);
        }
      }
      else if (this.m_mode <= m)
      {
        if (this.m_mode == n)
          this.m_logger.log(1, "IF1 not supported; defaulting to 128k");
        if (this.m_mode == i1)
          this.m_logger.log(1, "MGT not supported; defaulting to 48k");
        this.m_mode = 1;
        for (i2 = 0; i2 < 8; i2++)
          loadPage(paramInputStream, i2, false);
      }
      else
      {
        throw new IOException("JZXFrame does not support the +3 Spectrum");
      }
    }
  }

  protected void loadPage(InputStream paramInputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    PageHeader localPageHeader = new PageHeader();
    localPageHeader.load(paramInputStream);
    int i = localPageHeader.getPageLength();
    int j = localPageHeader.getPageNumber();
    int k;
    int m;
    if (paramBoolean)
    {
      if (i == 65535)
        i = 16384;
      for (k = 0; k < i; k++)
      {
        m = paramInputStream.read();
        if (m == -1)
          break;
      }
      return;
    }
    if (this.m_mode == 0)
      switch (j)
      {
      case 4:
        k = 6;
        break;
      case 5:
        k = 4;
        break;
      case 8:
        k = 9;
        break;
      case 6:
      case 7:
      default:
        throw new IOException("Invalid page number for 48k snapshot: " + j);
      }
    else
      k = 4 + j - 3;
    if (i == 65535)
    {
      m = paramInputStream.read(this.m_memory.getBytes(k));
      if (m != 16384)
        throw new IOException("Block " + paramInt + " is too short: " + m);
    }
    else
    {
      byte[] arrayOfByte = this.m_memory.getBytes(k);
      int n = 0;
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      int i4 = 0;
      while (i4 < i)
      {
        i4++;
        if (i1 != 0)
        {
          i1 = 0;
        }
        else
        {
          i2 = paramInputStream.read();
          if (i2 == -1)
            break;
          i3 = (byte)i2;
        }
        if (i3 != -19)
        {
          arrayOfByte[(n++)] = i3;
        }
        else
        {
          i4++;
          i2 = paramInputStream.read();
          if (i2 == -1)
            break;
          i3 = (byte)i2;
          if (i3 != -19)
          {
            arrayOfByte[(n++)] = -19;
            i1 = 1;
            i4--;
          }
          else
          {
            int i5 = paramInputStream.read();
            if (i5 == -1)
              break;
            i5 &= 255;
            i4++;
            i2 = paramInputStream.read();
            if (i2 == -1)
              break;
            i3 = (byte)i2;
            i4++;
            while (i5-- != 0)
              arrayOfByte[(n++)] = i3;
          }
        }
      }
      if (n != 16384)
        throw new IOException("Block " + paramInt + " contains only: " + n + " bytes");
    }
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.Z80Loader
 * JD-Core Version:    0.6.2
 */