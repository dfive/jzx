package org.razvan.jzx.v128;

import org.razvan.jzx.BaseComponent;
import org.razvan.jzx.BaseIO;
import org.razvan.jzx.BaseLoader;
import org.razvan.jzx.ILogger;

public class AY8912 extends BaseComponent
{
  private static final int AY8912_FREQ = 221660;
  private static final int FREQ_SCALE = 4;
  private static int MAX_CHANNEL_VOLUME = 15;
  private static final int R_FTC_A = 0;
  private static final int R_CTC_A = 1;
  private static final int R_FTC_B = 2;
  private static final int R_CTC_B = 3;
  private static final int R_FTC_C = 4;
  private static final int R_CTC_C = 5;
  private static final int R_NOISE = 6;
  private static final int R_MIXER = 7;
  private static final int R_AMP_A = 8;
  private static final int R_AMP_B = 9;
  private static final int R_AMP_C = 10;
  private static final int R_FPC_E = 11;
  private static final int R_CPC_E = 12;
  private static final int R_ENVELOPE = 13;
  private static final int R_RS232_A = 14;
  private static final int R_RS232_B = 15;
  private static final int ENV_ATTACK = 0;
  private static final int ENV_DECAY = 1;
  private static final int ENV_SUSTAIN_LOW = 2;
  private static final int ENV_SUSTAIN_HIGH = 3;
  private static final int ENV_REPEAT = 4;
  private static final int ENV_RESTART = 5;
  private static final int ENV_ERROR = 6;
  private static final int[][] ENVELOPES = { { 1, 2, 4 }, { 1, 2, 4 }, { 1, 2, 4 }, { 1, 2, 4 }, { 0, 2, 4 }, { 0, 2, 4 }, { 0, 2, 4 }, { 0, 2, 4 }, { 1, 4, 6 }, { 1, 2, 4 }, { 1, 0, 5 }, { 1, 3, 4 }, { 0, 4, 6 }, { 0, 3, 4 }, { 0, 1, 5 }, { 0, 2, 4 } };
  private int m_pitchA;
  private int m_pitchB;
  private int m_pitchC;
  private int m_periodN;
  private int m_mixer;
  private int m_amplitudeA;
  private int m_amplitudeB;
  private int m_amplitudeC;
  private int m_periodE;
  private int m_envelopeType;
  private boolean m_useEnvelopeA;
  private boolean m_useEnvelopeB;
  private boolean m_useEnvelopeC;
  private int m_rs232a;
  private int m_rs232b;
  private int _counterA = 0;
  private int _counterB = 0;
  private int _counterC = 0;
  private boolean _generatorA = false;
  private boolean _generatorB = false;
  private boolean _generatorC = false;
  private int _counterN = 0;
  private boolean _generatorN = false;
  private int _counterE = 0;
  private int _tickE = 0;
  private int _envelopeState = 0;

  public void reset()
  {
  }

  public void load(BaseLoader paramBaseLoader)
  {
  }

  public void out8(int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    case 0:
      this.m_pitchA = (this.m_pitchA & 0xF00 | paramInt2);
      break;
    case 1:
      this.m_pitchA = ((paramInt2 & 0xF) << 8 | this.m_pitchA & 0xFF);
      break;
    case 2:
      this.m_pitchB = (this.m_pitchB & 0xF00 | paramInt2);
      break;
    case 3:
      this.m_pitchB = ((paramInt2 & 0xF) << 8 | this.m_pitchB & 0xFF);
      break;
    case 4:
      this.m_pitchC = (this.m_pitchC & 0xF00 | paramInt2);
      break;
    case 5:
      this.m_pitchC = ((paramInt2 & 0xF) << 8 | this.m_pitchC & 0xFF);
      break;
    case 6:
      this.m_periodN = (paramInt2 & 0x1F);
      break;
    case 7:
      this.m_mixer = paramInt2;
      break;
    case 8:
      this.m_amplitudeA = (paramInt2 & 0xF);
      this.m_useEnvelopeA = ((paramInt2 & 0x10) != 0);
      break;
    case 9:
      this.m_amplitudeB = (paramInt2 & 0xF);
      this.m_useEnvelopeB = ((paramInt2 & 0x10) != 0);
      break;
    case 10:
      this.m_amplitudeC = (paramInt2 & 0xF);
      this.m_useEnvelopeC = ((paramInt2 & 0x10) != 0);
      break;
    case 11:
      this.m_periodE = (this.m_periodE & 0xFF00 | paramInt2);
      break;
    case 12:
      this.m_periodE = (paramInt2 << 8 | this.m_periodE & 0xFF);
      break;
    case 13:
      this.m_envelopeType = (paramInt2 & 0xF);
      this._envelopeState = 0;
      this._counterE = 0;
      this._tickE = 0;
      break;
    case 14:
      this.m_rs232a = paramInt2;
      break;
    case 15:
      this.m_rs232b = paramInt2;
      break;
    default:
      this.m_logger.log(0, "Unknown AY register: " + paramInt1);
    }
  }

  public int getSound(int paramInt)
  {
    int i = BaseIO.getAudioSamplesForTStates(paramInt);
    if (this.m_pitchA > 0)
    {
      this._counterA += i * 4;
      if (this._counterA >= this.m_pitchA)
      {
        this._generatorA = (!this._generatorA);
        this._counterA -= this.m_pitchA;
      }
    }
    if (this.m_pitchB > 0)
    {
      this._counterB += i * 4;
      if (this._counterB >= this.m_pitchB)
      {
        this._generatorB = (!this._generatorB);
        this._counterB -= this.m_pitchB;
      }
    }
    if (this.m_pitchC > 0)
    {
      this._counterC += i * 4;
      if (this._counterC >= this.m_pitchC)
      {
        this._generatorC = (!this._generatorC);
        this._counterC -= this.m_pitchC;
      }
    }
    if (this.m_periodN > 0)
    {
      this._counterN += i * 4;
      if (this._counterN >= this.m_periodN << 1)
      {
        this._counterN -= (this.m_periodN << 1);
        this._generatorN = (Math.random() >= 0.5D);
      }
    }
    int[] arrayOfInt = ENVELOPES[this.m_envelopeType];
    int j = 0;
    if (this.m_periodE > 0)
    {
      this._counterE += i * 4;
      if (this._counterE >= this.m_periodE << 1)
      {
        this._counterE -= (this.m_periodE << 1);
        this._tickE += 1;
        if (this._tickE == MAX_CHANNEL_VOLUME)
        {
          this._tickE = 0;
          this._envelopeState += 1;
          switch (arrayOfInt[this._envelopeState])
          {
          case 4:
            this._envelopeState -= 1;
            break;
          case 5:
            this._envelopeState = 0;
            break;
          case 6:
            this.m_logger.log(0, "Illegal envelope state reached: " + arrayOfInt[this._envelopeState]);
            break;
          }
        }
        switch (arrayOfInt[this._envelopeState])
        {
        case 0:
          j = this._tickE;
          break;
        case 1:
          j = MAX_CHANNEL_VOLUME - this._tickE;
          break;
        case 2:
          j = 0;
          break;
        case 3:
          j = MAX_CHANNEL_VOLUME;
          break;
        default:
          this.m_logger.log(0, "Illegal envelope state reached: " + arrayOfInt[this._envelopeState]);
        }
      }
    }
    int k = this.m_useEnvelopeA ? j : this.m_amplitudeA;
    int m = this.m_useEnvelopeB ? j : this.m_amplitudeB;
    int n = this.m_useEnvelopeC ? j : this.m_amplitudeC;
    int i1 = 0;
    if ((((this.m_mixer & 0x1) == 0) && (this._generatorA)) || (((this.m_mixer & 0x8) == 0) && (this._generatorN)))
      i1 += k;
    if ((((this.m_mixer & 0x2) == 0) && (this._generatorB)) || (((this.m_mixer & 0x10) == 0) && (this._generatorN)))
      i1 += m;
    if ((((this.m_mixer & 0x4) == 0) && (this._generatorC)) || (((this.m_mixer & 0x20) == 0) && (this._generatorN)))
      i1 += n;
    i1 = i1 * 255 / (3 * MAX_CHANNEL_VOLUME);
    return i1;
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v128.AY8912
 * JD-Core Version:    0.6.2
 */