package org.razvan.jzx.v128;

import java.awt.Component;
import org.razvan.jzx.BaseIO;
import org.razvan.jzx.BaseLoader;
import org.razvan.jzx.BaseMemory;
import org.razvan.jzx.BaseScreen;
import org.razvan.jzx.BaseSpectrum;
import org.razvan.jzx.ILogger;

public class IO extends BaseIO
{
  public static final int P_128 = 253;
  public static final int P_BANK128 = 32765;
  public static final int B_BANK128 = 32770;
  public static final int B_SELRAM = 7;
  public static final int B_SELSCREEN = 8;
  public static final int B_SELROM = 16;
  public static final int B_PAGING = 32;
  public static final int P_SNDCONTROL = 65533;
  public static final int P_SNDDATA = 49149;
  public static final int B_SNDCHIP = 32770;
  public static final int B_SNDCONTROL = 16384;
  public static final int B_SNDDATA = 16384;
  protected int m_last0x7ffd;
  protected int m_last0xfffd;
  protected int[] m_psgPorts;
  protected AY8912 m_ay8912;

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    this.m_psgPorts = new int[16];
    this.m_ay8912 = ((Spectrum)paramBaseSpectrum).getAY8912();
  }

  public void reset()
  {
    for (int i = 0; i < 16; i++)
      this.m_psgPorts[i] = 0;
    super.reset();
  }

  public void terminate()
  {
    this.m_psgPorts = null;
    this.m_ay8912 = null;
    super.terminate();
  }

  public int in8(int paramInt)
  {
    int i = super.in8(paramInt);
    if (((paramInt & 0xFF) == 253) && ((paramInt & 0xC002) == 49152))
    {
      if (this.m_last0xfffd == 14)
        return 255;
      return this.m_psgPorts[this.m_last0xfffd];
    }
    return i;
  }

  public void out(int paramInt1, int paramInt2)
  {
    super.out(paramInt1, paramInt2);
    if ((paramInt1 & 0xFF) == 253)
      if ((paramInt1 & 0x8002) == 32768)
      {
        if ((paramInt1 & 0x4000) != 0)
        {
          this.m_last0xfffd = paramInt2;
        }
        else
        {
          this.m_psgPorts[this.m_last0xfffd] = paramInt2;
          if (this.m_last0xfffd < 14)
            this.m_ay8912.out8(this.m_last0xfffd, paramInt2);
        }
      }
      else if ((paramInt1 & 0x8002) == 0)
      {
        if ((this.m_last0x7ffd == paramInt2) || ((this.m_last0x7ffd & 0x20) != 0))
          return;
        this.m_screen.setPage((paramInt2 & 0x8) != 0 ? 11 : 9);
        if ((paramInt2 & 0x8) != (this.m_last0x7ffd & 0x8))
        {
          this.m_screen.reset();
          this.m_screen.repaint();
        }
        this.m_last0x7ffd = paramInt2;
        this.m_memory.pageIn(3, 4 + (paramInt2 & 0x7));
        this.m_memory.pageIn(0, 0 + ((paramInt2 & 0x10) >> 4));
      }
  }

  public void advance(int paramInt)
  {
    mixSound(paramInt, this.m_ay8912.getSound(paramInt));
    super.advance(paramInt);
  }

  public void load(BaseLoader paramBaseLoader)
  {
    super.load(paramBaseLoader);
    out(32765, paramBaseLoader.getLast0x7ffd());
    out(65533, paramBaseLoader.getLast0xfffd());
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v128.IO
 * JD-Core Version:    0.6.2
 */