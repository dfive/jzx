package org.razvan.jzx.v128;

import java.io.IOException;
import org.razvan.jzx.BaseMemory;
import org.razvan.jzx.BaseSpectrum;
import org.razvan.jzx.ILogger;

public class Memory extends BaseMemory
{
  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    super.init(paramBaseSpectrum, paramILogger);
    try
    {
      readROM("/128a.rom", this.m_page[0]);
      readROM("/128b.rom", this.m_page[1]);
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException(localIOException.getMessage());
    }
  }

  public void reset()
  {
    for (int i = 2; i <= 11; i++)
      for (int j = 0; j < 16384; j++)
        this.m_page[i][j] = ((byte)(int)(Math.random() * 256.0D));
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v128.Memory
 * JD-Core Version:    0.6.2
 */