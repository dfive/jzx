package org.razvan.jzx.v128;

import org.razvan.jzx.BaseComponent;
import org.razvan.jzx.BaseKeyboard;
import org.razvan.jzx.BaseScreen;
import org.razvan.jzx.BaseSpectrum;
import org.razvan.jzx.ILogger;
import org.razvan.jzx.Z80;

public class Spectrum extends BaseSpectrum
{
  protected AY8912 m_ay8912;

  public AY8912 getAY8912()
  {
    return this.m_ay8912;
  }

  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    this.m_cpu = new Z80();
    this.m_memory = new Memory();
    this.m_io = new IO();
    this.m_screen = BaseScreen.getInstance();
    this.m_keyboard = new BaseKeyboard();
    this.m_ay8912 = new AY8912();
    super.init(paramBaseSpectrum, paramILogger);
    this.m_ay8912.init(paramBaseSpectrum, paramILogger);
    this.m_tvLines = 311;
    this.m_cyclesLine = 228;
  }

  public String getMode()
  {
    return "128";
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v128.Spectrum
 * JD-Core Version:    0.6.2
 */