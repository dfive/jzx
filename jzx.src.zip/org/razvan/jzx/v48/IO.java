package org.razvan.jzx.v48;

import org.razvan.jzx.BaseIO;

public class IO extends BaseIO
{
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v48.IO
 * JD-Core Version:    0.6.2
 */