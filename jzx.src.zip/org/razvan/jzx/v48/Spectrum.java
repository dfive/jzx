package org.razvan.jzx.v48;

import org.razvan.jzx.BaseKeyboard;
import org.razvan.jzx.BaseScreen;
import org.razvan.jzx.BaseSpectrum;
import org.razvan.jzx.ILogger;
import org.razvan.jzx.Z80;

public class Spectrum extends BaseSpectrum
{
  public void init(BaseSpectrum paramBaseSpectrum, ILogger paramILogger)
  {
    this.m_cpu = new Z80();
    this.m_memory = new Memory();
    this.m_io = new IO();
    this.m_screen = BaseScreen.getInstance();
    this.m_keyboard = new BaseKeyboard();
    super.init(paramBaseSpectrum, paramILogger);
    this.m_tvLines = 312;
    this.m_cyclesLine = 224;
  }

  public String getMode()
  {
    return "48";
  }
}

/* Location:           C:\Users\SONY\Desktop\jzx.jar
 * Qualified Name:     org.razvan.jzx.v48.Spectrum
 * JD-Core Version:    0.6.2
 */